import { useState, useEffect, useMemo } from "react";

// ═══════════════════════════════════════════════════════════════
// الأدبية — لوحة التحليل البصرية
// Al-Adabiya — Visual Analysis Dashboard
// 20 مدخل × 4 إطارات = 80 صوت
// ═══════════════════════════════════════════════════════════════

// --- Sample Data for demonstration ---
const SAMPLE_DATA = {
  symbol: "BTC/USDT",
  current_price: 97542.00,
  timestamp: new Date().toISOString(),
  timeframes: {
    monthly: {
      rank: "sultan", rank_ar: "السُّلطان", timeframe: "الشهري",
      big_score: 0.82, med_score: 0.65, small_score: 0.40, total_score: 0.70,
      direction: "up", net_arrow: 0.75, support: 88000, resistance: 105000,
      inputs: [
        { name: "DOW", name_ar: "نمط داو", layer: "BIG", weight: 25, value: 1.0, description: "صاعد (قمم أعلى + قيعان أعلى)" },
        { name: "SEC", name_ar: "القناة", layer: "BIG", weight: 20, value: 1.0, description: "قناة صاعدة، السعر فوق الكل" },
        { name: "MA", name_ar: "المتوسطات", layer: "BIG", weight: 20, value: 1.0, description: "شمعتين فوق + سريع فوق بطيء" },
        { name: "MACD₀", name_ar: "MACD مقابل ٠", layer: "BIG", weight: 20, value: 1.0, description: "فوق الصفر = أرض الثيران" },
        { name: "ROC25₀", name_ar: "ROC(25) مقابل ٠", layer: "BIG", weight: 15, value: 0.5, description: "فوق الصفر لكن يتباطأ" },
        { name: "ROC25T", name_ar: "ROC(25) ترند", layer: "MED", weight: 18, value: 0.5, description: "تحول غير مكتمل" },
        { name: "ROC14₀", name_ar: "ROC(14) مقابل ٠", layer: "MED", weight: 18, value: 1.0, description: "فوق الصفر" },
        { name: "MACDₛ", name_ar: "MACD مقابل الإشارة", layer: "MED", weight: 22, value: 1.0, description: "الزخم يتسارع" },
        { name: "RSI_T", name_ar: "RSI ترند", layer: "MED", weight: 22, value: 0.5, description: "ترند صاعد مع تباطؤ" },
        { name: "IMI_T", name_ar: "IMI ترند", layer: "MED", weight: 20, value: 0.5, description: "صاعد لكن بطيء" },
        { name: "ROC14T", name_ar: "ROC(14) ترند", layer: "SMALL", weight: 12, value: 1.0, description: "هيكل صاعد واضح" },
        { name: "ROC7₀", name_ar: "ROC(7) مقابل ٠", layer: "SMALL", weight: 12, value: -1.0, description: "تحت الصفر = تصحيح قصير" },
        { name: "HIST", name_ar: "هيستوغرام", layer: "SMALL", weight: 16, value: -0.5, description: "إيجابي لكن يتقلص" },
        { name: "STOCH", name_ar: "ستوكاستيك", layer: "SMALL", weight: 16, value: null, description: "بين ٢٠-٨٠ = صامت" },
        { name: "REV", name_ar: "الانعكاسات", layer: "SMALL", weight: 16, value: 0.0, description: "لا يوجد نمط" },
        { name: "CNDL", name_ar: "الشموع", layer: "SMALL", weight: 14, value: 1.0, description: "ابتلاع صعودي ٧٢%" },
        { name: "BB", name_ar: "بولنجر", layer: "SMALL", weight: 14, value: 1.0, description: "إغلاق فوق المتوسط" },
      ]
    },
    weekly: {
      rank: "wazir", rank_ar: "الوزير", timeframe: "الأسبوعي",
      big_score: 0.72, med_score: 0.55, small_score: 0.35, total_score: 0.58,
      direction: "up", net_arrow: 0.60, support: 91000, resistance: 102000,
      inputs: [
        { name: "DOW", name_ar: "نمط داو", layer: "BIG", weight: 25, value: 1.0, description: "صاعد مؤكد" },
        { name: "SEC", name_ar: "القناة", layer: "BIG", weight: 20, value: 1.0, description: "قناة صاعدة" },
        { name: "MA", name_ar: "المتوسطات", layer: "BIG", weight: 20, value: 0.5, description: "شمعة واحدة فقط" },
        { name: "MACD₀", name_ar: "MACD مقابل ٠", layer: "BIG", weight: 20, value: 1.0, description: "فوق الصفر" },
        { name: "ROC25₀", name_ar: "ROC(25) مقابل ٠", layer: "BIG", weight: 15, value: 1.0, description: "فوق الصفر" },
        { name: "ROC25T", name_ar: "ROC(25) ترند", layer: "MED", weight: 18, value: 1.0, description: "ترند صاعد" },
        { name: "ROC14₀", name_ar: "ROC(14) مقابل ٠", layer: "MED", weight: 18, value: 0.5, description: "قريب من الصفر" },
        { name: "MACDₛ", name_ar: "MACD مقابل الإشارة", layer: "MED", weight: 22, value: 1.0, description: "فوق الإشارة" },
        { name: "RSI_T", name_ar: "RSI ترند", layer: "MED", weight: 22, value: 0.5, description: "نصف إشارة" },
        { name: "IMI_T", name_ar: "IMI ترند", layer: "MED", weight: 20, value: 0.0, description: "محايد" },
        { name: "ROC14T", name_ar: "ROC(14) ترند", layer: "SMALL", weight: 12, value: 0.5, description: "نصف إشارة" },
        { name: "ROC7₀", name_ar: "ROC(7) مقابل ٠", layer: "SMALL", weight: 12, value: 1.0, description: "فوق الصفر" },
        { name: "HIST", name_ar: "هيستوغرام", layer: "SMALL", weight: 16, value: 0.5, description: "ينمو ببطء" },
        { name: "STOCH", name_ar: "ستوكاستيك", layer: "SMALL", weight: 16, value: -1.0, description: "تقاطع هبوطي فوق ٨٠" },
        { name: "REV", name_ar: "الانعكاسات", layer: "SMALL", weight: 16, value: 0.0, description: "لا يوجد" },
        { name: "CNDL", name_ar: "الشموع", layer: "SMALL", weight: 14, value: 0.0, description: "لا يوجد نمط" },
        { name: "BB", name_ar: "بولنجر", layer: "SMALL", weight: 14, value: 0.5, description: "HOOK عند العلوي" },
      ]
    },
    daily: {
      rank: "commander", rank_ar: "القائد", timeframe: "اليومي",
      big_score: 0.65, med_score: 0.30, small_score: -0.20, total_score: 0.38,
      direction: "up", net_arrow: 0.30, support: 94500, resistance: 100000,
      inputs: [
        { name: "DOW", name_ar: "نمط داو", layer: "BIG", weight: 25, value: 1.0, description: "صاعد" },
        { name: "SEC", name_ar: "القناة", layer: "BIG", weight: 20, value: 0.5, description: "عند الحدود" },
        { name: "MA", name_ar: "المتوسطات", layer: "BIG", weight: 20, value: 1.0, description: "مؤكد" },
        { name: "MACD₀", name_ar: "MACD مقابل ٠", layer: "BIG", weight: 20, value: 1.0, description: "فوق الصفر" },
        { name: "ROC25₀", name_ar: "ROC(25) مقابل ٠", layer: "BIG", weight: 15, value: -1.0, description: "تحت الصفر" },
        { name: "ROC25T", name_ar: "ROC(25) ترند", layer: "MED", weight: 18, value: -0.5, description: "يتباطأ" },
        { name: "ROC14₀", name_ar: "ROC(14) مقابل ٠", layer: "MED", weight: 18, value: 1.0, description: "فوق الصفر" },
        { name: "MACDₛ", name_ar: "MACD مقابل الإشارة", layer: "MED", weight: 22, value: -1.0, description: "تحت الإشارة = يتباطأ" },
        { name: "RSI_T", name_ar: "RSI ترند", layer: "MED", weight: 22, value: 1.0, description: "ترند صاعد" },
        { name: "IMI_T", name_ar: "IMI ترند", layer: "MED", weight: 20, value: 0.5, description: "نصف إشارة" },
        { name: "ROC14T", name_ar: "ROC(14) ترند", layer: "SMALL", weight: 12, value: -1.0, description: "هابط" },
        { name: "ROC7₀", name_ar: "ROC(7) مقابل ٠", layer: "SMALL", weight: 12, value: -1.0, description: "تحت الصفر" },
        { name: "HIST", name_ar: "هيستوغرام", layer: "SMALL", weight: 16, value: -1.0, description: "سلبي وينمو" },
        { name: "STOCH", name_ar: "ستوكاستيك", layer: "SMALL", weight: 16, value: 1.0, description: "تقاطع صعودي تحت ٢٠" },
        { name: "REV", name_ar: "الانعكاسات", layer: "SMALL", weight: 16, value: 0.5, description: "نمط لكن بدون تأكيد" },
        { name: "CNDL", name_ar: "الشموع", layer: "SMALL", weight: 14, value: 0.0, description: "لا يوجد" },
        { name: "BB", name_ar: "بولنجر", layer: "SMALL", weight: 14, value: -0.5, description: "HOOK عند السفلي" },
      ]
    },
    hourly: {
      rank: "soldier", rank_ar: "الجندي", timeframe: "الساعة",
      big_score: -0.45, med_score: -0.35, small_score: -0.55, total_score: -0.43,
      direction: "down", net_arrow: -0.38, support: 96200, resistance: 98500,
      inputs: [
        { name: "DOW", name_ar: "نمط داو", layer: "BIG", weight: 25, value: -1.0, description: "هابط (قمم أدنى + قيعان أدنى)" },
        { name: "SEC", name_ar: "القناة", layer: "BIG", weight: 20, value: -1.0, description: "قناة هابطة" },
        { name: "MA", name_ar: "المتوسطات", layer: "BIG", weight: 20, value: -1.0, description: "تحت + سريع تحت بطيء" },
        { name: "MACD₀", name_ar: "MACD مقابل ٠", layer: "BIG", weight: 20, value: -1.0, description: "تحت الصفر = أرض الدببة" },
        { name: "ROC25₀", name_ar: "ROC(25) مقابل ٠", layer: "BIG", weight: 15, value: 1.0, description: "لا يزال فوق الصفر" },
        { name: "ROC25T", name_ar: "ROC(25) ترند", layer: "MED", weight: 18, value: -1.0, description: "هابط" },
        { name: "ROC14₀", name_ar: "ROC(14) مقابل ٠", layer: "MED", weight: 18, value: -1.0, description: "تحت الصفر" },
        { name: "MACDₛ", name_ar: "MACD مقابل الإشارة", layer: "MED", weight: 22, value: 0.5, description: "يقترب من الإشارة" },
        { name: "RSI_T", name_ar: "RSI ترند", layer: "MED", weight: 22, value: -0.5, description: "هابط مع تباطؤ", divergence: true },
        { name: "IMI_T", name_ar: "IMI ترند", layer: "MED", weight: 20, value: -1.0, description: "هابط" },
        { name: "ROC14T", name_ar: "ROC(14) ترند", layer: "SMALL", weight: 12, value: -1.0, description: "هابط" },
        { name: "ROC7₀", name_ar: "ROC(7) مقابل ٠", layer: "SMALL", weight: 12, value: -1.0, description: "تحت الصفر" },
        { name: "HIST", name_ar: "هيستوغرام", layer: "SMALL", weight: 16, value: -0.5, description: "سلبي لكن يتقلص" },
        { name: "STOCH", name_ar: "ستوكاستيك", layer: "SMALL", weight: 16, value: null, description: "صامت (بين ٢٠-٨٠)" },
        { name: "REV", name_ar: "الانعكاسات", layer: "SMALL", weight: 16, value: -1.0, description: "انعكاس هبوطي مؤكد" },
        { name: "CNDL", name_ar: "الشموع", layer: "SMALL", weight: 14, value: -1.0, description: "ابتلاع هبوطي" },
        { name: "BB", name_ar: "بولنجر", layer: "SMALL", weight: 14, value: -1.0, description: "FS هبوطي خارج→داخل" },
      ]
    }
  },
  adab: {
    status: "soldier_correction", status_ar: "⚔️ تصحيح الجندي",
    confidence: 75, opportunity: "buy",
    reasoning: [
      "السلطان (الشهري): صاعد بقوة +0.70",
      "الوزير (الأسبوعي): يوافق السلطان +0.58",
      "القائد (اليومي): يوافق الأعلى +0.38",
      "⚔️ الجندي (الساعة): يصحح -0.43 ← فرصة!",
      "تصحيح الجندي في ترند السلطان = فرصة ذهبية"
    ]
  }
};

// --- Helper Functions ---
const getSignalColor = (value) => {
  if (value === null || value === undefined) return { bg: "#1a1a2e", text: "#555", border: "#333" };
  if (value >= 0.9) return { bg: "#0a3d0a", text: "#4ade80", border: "#166534" };
  if (value >= 0.4) return { bg: "#3d3d0a", text: "#fbbf24", border: "#854d0e" };
  if (Math.abs(value) < 0.1) return { bg: "#1a1a2e", text: "#94a3b8", border: "#334155" };
  if (value <= -0.9) return { bg: "#3d0a0a", text: "#f87171", border: "#991b1b" };
  if (value <= -0.4) return { bg: "#3d2a0a", text: "#fb923c", border: "#92400e" };
  return { bg: "#1a1a2e", text: "#94a3b8", border: "#334155" };
};

const getSignalIcon = (value) => {
  if (value === null || value === undefined) return "✖";
  if (value >= 0.9) return "▲";
  if (value >= 0.4) return "△?";
  if (Math.abs(value) < 0.1) return "■";
  if (value <= -0.9) return "▼";
  if (value <= -0.4) return "▽?";
  return "■";
};

const getLayerColor = (layer) => {
  if (layer === "BIG") return "#c084fc";
  if (layer === "MED") return "#60a5fa";
  return "#34d399";
};

const getRankStyle = (rank) => {
  const styles = {
    sultan: { emoji: "👑", gradient: "linear-gradient(135deg, #ffd700 0%, #b8860b 100%)", shadow: "#ffd70040" },
    wazir: { emoji: "⚜️", gradient: "linear-gradient(135deg, #c0c0c0 0%, #808080 100%)", shadow: "#c0c0c040" },
    commander: { emoji: "⚔️", gradient: "linear-gradient(135deg, #cd7f32 0%, #8b4513 100%)", shadow: "#cd7f3240" },
    soldier: { emoji: "🗡️", gradient: "linear-gradient(135deg, #4a5568 0%, #2d3748 100%)", shadow: "#4a556840" },
  };
  return styles[rank] || styles.soldier;
};

// --- Components ---

const SignalCell = ({ value, description, divergence, weight }) => {
  const colors = getSignalColor(value);
  const icon = getSignalIcon(value);
  return (
    <div style={{
      background: colors.bg,
      border: `1px solid ${colors.border}`,
      borderRadius: "6px",
      padding: "4px 6px",
      display: "flex",
      alignItems: "center",
      gap: "4px",
      position: "relative",
      cursor: "default",
      minWidth: "60px",
      justifyContent: "center",
      transition: "all 0.2s",
    }}
    title={description}
    >
      <span style={{ color: colors.text, fontSize: "14px", fontWeight: 700 }}>{icon}</span>
      <span style={{ color: colors.text, fontSize: "11px", fontWeight: 500 }}>
        {value !== null && value !== undefined ? (value > 0 ? `+${value.toFixed(1)}` : value.toFixed(1)) : "X"}
      </span>
      {divergence && <span style={{ position: "absolute", top: -4, right: -4, fontSize: "10px" }}>🔀</span>}
      <span style={{ color: "#555", fontSize: "8px", position: "absolute", bottom: 1, right: 3 }}>{weight}</span>
    </div>
  );
};

const ScoreBar = ({ score, label, color }) => {
  const pct = ((score + 1) / 2) * 100;
  return (
    <div style={{ display: "flex", alignItems: "center", gap: "6px", marginBottom: "4px" }}>
      <span style={{ color: color, fontSize: "10px", fontWeight: 700, width: "40px", textAlign: "right" }}>{label}</span>
      <div style={{ flex: 1, height: "8px", background: "#111827", borderRadius: "4px", position: "relative", overflow: "hidden" }}>
        <div style={{
          position: "absolute",
          left: "50%",
          top: 0,
          height: "100%",
          width: `${Math.abs(score) * 50}%`,
          background: score > 0 ? "#22c55e" : "#ef4444",
          transform: score < 0 ? "translateX(-100%)" : "none",
          borderRadius: "4px",
          transition: "width 0.5s ease",
        }} />
        <div style={{ position: "absolute", left: "50%", top: 0, width: "1px", height: "100%", background: "#374151" }} />
      </div>
      <span style={{ color: score > 0.2 ? "#4ade80" : score < -0.2 ? "#f87171" : "#94a3b8", fontSize: "11px", fontWeight: 700, width: "42px" }}>
        {score > 0 ? "+" : ""}{score.toFixed(2)}
      </span>
    </div>
  );
};

const TimeframeCard = ({ data }) => {
  const [expanded, setExpanded] = useState(true);
  if (!data) return null;
  const rankStyle = getRankStyle(data.rank);
  const bigInputs = data.inputs.filter(i => i.layer === "BIG");
  const medInputs = data.inputs.filter(i => i.layer === "MED");
  const smallInputs = data.inputs.filter(i => i.layer === "SMALL");

  const dirColor = data.direction === "up" ? "#4ade80" : data.direction === "down" ? "#f87171" : "#94a3b8";
  const dirIcon = data.direction === "up" ? "↑" : data.direction === "down" ? "↓" : "→";

  return (
    <div style={{
      background: "#0f0f1a",
      borderRadius: "12px",
      border: "1px solid #1e1e3a",
      overflow: "hidden",
      boxShadow: `0 4px 20px ${rankStyle.shadow}`,
    }}>
      {/* Header */}
      <div onClick={() => setExpanded(!expanded)} style={{
        background: rankStyle.gradient,
        padding: "10px 14px",
        display: "flex",
        justifyContent: "space-between",
        alignItems: "center",
        cursor: "pointer",
      }}>
        <div style={{ display: "flex", alignItems: "center", gap: "8px" }}>
          <span style={{ fontSize: "20px" }}>{rankStyle.emoji}</span>
          <div>
            <div style={{ color: "#fff", fontWeight: 800, fontSize: "14px", fontFamily: "'Amiri', serif" }}>{data.rank_ar}</div>
            <div style={{ color: "#ffffffaa", fontSize: "10px" }}>{data.timeframe}</div>
          </div>
        </div>
        <div style={{ textAlign: "right" }}>
          <div style={{ color: dirColor, fontWeight: 900, fontSize: "22px", lineHeight: 1 }}>
            {dirIcon} {data.total_score > 0 ? "+" : ""}{data.total_score.toFixed(2)}
          </div>
          <div style={{ color: "#ffffffaa", fontSize: "9px" }}>
            S: {data.support?.toLocaleString()} | R: {data.resistance?.toLocaleString()}
          </div>
        </div>
      </div>

      {expanded && (
        <div style={{ padding: "10px" }}>
          {/* Score Bars */}
          <ScoreBar score={data.big_score} label="BIG" color="#c084fc" />
          <ScoreBar score={data.med_score} label="MED" color="#60a5fa" />
          <ScoreBar score={data.small_score} label="SMALL" color="#34d399" />

          {/* Separator */}
          <div style={{ height: "1px", background: "#1e1e3a", margin: "8px 0" }} />

          {/* Input Grid */}
          {[
            { label: "BIG (50%)", color: "#c084fc", inputs: bigInputs },
            { label: "MED (30%)", color: "#60a5fa", inputs: medInputs },
            { label: "SMALL (20%)", color: "#34d399", inputs: smallInputs },
          ].map(group => (
            <div key={group.label} style={{ marginBottom: "8px" }}>
              <div style={{ color: group.color, fontSize: "9px", fontWeight: 700, marginBottom: "4px", letterSpacing: "1px" }}>
                {group.label}
              </div>
              <div style={{ display: "flex", flexWrap: "wrap", gap: "3px" }}>
                {group.inputs.map((inp, i) => (
                  <div key={i} style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: "1px" }}>
                    <span style={{ color: "#555", fontSize: "7px", fontWeight: 600 }}>{inp.name}</span>
                    <SignalCell value={inp.value} description={inp.description} divergence={inp.divergence} weight={inp.weight} />
                  </div>
                ))}
              </div>
            </div>
          ))}

          {/* NET ARROW */}
          <div style={{
            marginTop: "6px",
            padding: "6px 10px",
            background: data.net_arrow > 0.2 ? "#0a3d0a" : data.net_arrow < -0.2 ? "#3d0a0a" : "#1a1a2e",
            borderRadius: "6px",
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
          }}>
            <span style={{ color: "#888", fontSize: "9px", fontWeight: 700 }}>NET ARROW</span>
            <span style={{
              color: data.net_arrow > 0.2 ? "#4ade80" : data.net_arrow < -0.2 ? "#f87171" : "#94a3b8",
              fontWeight: 900, fontSize: "14px",
            }}>
              {data.net_arrow > 0.2 ? "↑" : data.net_arrow < -0.2 ? "↓" : "→"} {data.net_arrow > 0 ? "+" : ""}{data.net_arrow.toFixed(2)}
            </span>
          </div>
        </div>
      )}
    </div>
  );
};

const AdabPanel = ({ adab }) => {
  if (!adab) return null;
  const bgMap = {
    full_agreement: "linear-gradient(135deg, #064e3b 0%, #0f2d1f 100%)",
    soldier_correction: "linear-gradient(135deg, #1e3a5f 0%, #0f1b2d 100%)",
    commander_correction: "linear-gradient(135deg, #3d2800 0%, #1a1100 100%)",
    wazir_rebellion: "linear-gradient(135deg, #5f1e1e 0%, #2d0f0f 100%)",
    wait: "linear-gradient(135deg, #1f2937 0%, #111827 100%)",
  };
  const borderMap = {
    full_agreement: "#22c55e",
    soldier_correction: "#3b82f6",
    commander_correction: "#f59e0b",
    wazir_rebellion: "#ef4444",
    wait: "#6b7280",
  };

  return (
    <div style={{
      background: bgMap[adab.status] || bgMap.wait,
      border: `2px solid ${borderMap[adab.status] || "#6b7280"}`,
      borderRadius: "14px",
      padding: "16px",
      marginTop: "16px",
    }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "12px" }}>
        <div>
          <div style={{ color: "#fff", fontWeight: 900, fontSize: "20px", fontFamily: "'Amiri', serif" }}>
            {adab.status_ar}
          </div>
          <div style={{ color: "#94a3b8", fontSize: "11px" }}>الأدبية — التسلسل الهرمي</div>
        </div>
        <div style={{ textAlign: "right" }}>
          <div style={{ color: borderMap[adab.status], fontWeight: 900, fontSize: "28px" }}>
            {adab.confidence}%
          </div>
          <div style={{
            color: adab.opportunity === "buy" ? "#4ade80" : adab.opportunity === "sell" ? "#f87171" : "#fbbf24",
            fontSize: "12px", fontWeight: 700, textTransform: "uppercase",
          }}>
            {adab.opportunity === "buy" ? "🟢 شراء" : adab.opportunity === "sell" ? "🔴 بيع" : "🟡 انتظار"}
          </div>
        </div>
      </div>

      <div style={{ display: "flex", flexDirection: "column", gap: "4px" }}>
        {adab.reasoning.map((r, i) => (
          <div key={i} style={{
            color: r.includes("⚔️") || r.includes("🚨") ? "#fbbf24" : r.includes("فرصة") ? "#4ade80" : "#cbd5e1",
            fontSize: "11px",
            padding: "3px 8px",
            background: "#00000030",
            borderRadius: "4px",
            fontFamily: "'Amiri', serif",
          }}>
            {r}
          </div>
        ))}
      </div>
    </div>
  );
};

// --- Legend ---
const Legend = () => (
  <div style={{
    display: "flex", flexWrap: "wrap", gap: "10px", justifyContent: "center",
    padding: "8px 12px", background: "#0a0a15", borderRadius: "8px", marginBottom: "12px",
    border: "1px solid #1e1e3a",
  }}>
    {[
      { icon: "▲", label: "+1 مؤكد", color: "#4ade80" },
      { icon: "△?", label: "+0.5 نصف", color: "#fbbf24" },
      { icon: "■", label: "0 محايد", color: "#94a3b8" },
      { icon: "▽?", label: "-0.5 نصف", color: "#fb923c" },
      { icon: "▼", label: "-1 مؤكد", color: "#f87171" },
      { icon: "✖", label: "X مستبعد", color: "#555" },
      { icon: "🔀", label: "دايفرجنس", color: "#a78bfa" },
    ].map((item, i) => (
      <div key={i} style={{ display: "flex", alignItems: "center", gap: "4px" }}>
        <span style={{ color: item.color, fontWeight: 700, fontSize: "12px" }}>{item.icon}</span>
        <span style={{ color: item.color, fontSize: "9px" }}>{item.label}</span>
      </div>
    ))}
  </div>
);

// --- Main Component ---
export default function AdabiyaDashboard() {
  const [data] = useState(SAMPLE_DATA);

  return (
    <div style={{
      minHeight: "100vh",
      background: "#070710",
      color: "#e2e8f0",
      fontFamily: "'Segoe UI', system-ui, sans-serif",
      padding: "12px",
      direction: "rtl",
    }}>
      {/* Header */}
      <div style={{
        textAlign: "center",
        marginBottom: "16px",
        padding: "14px",
        background: "linear-gradient(135deg, #0f0f2a 0%, #1a0a2e 50%, #0f0f2a 100%)",
        borderRadius: "14px",
        border: "1px solid #2e1a4a",
      }}>
        <div style={{ fontSize: "11px", color: "#a78bfa", letterSpacing: "4px", fontWeight: 600, marginBottom: "4px" }}>
          ٢٠ مدخل × ٤ إطارات = ٨٠ صوت
        </div>
        <div style={{ fontSize: "28px", fontWeight: 900, fontFamily: "'Amiri', serif", color: "#f0e6ff", letterSpacing: "2px" }}>
          الأدبية
        </div>
        <div style={{ fontSize: "10px", color: "#7c3aed", marginTop: "4px" }}>
          دورة ٦/٦/٢٠٠٦ — جميع الحقوق محفوظة لعماد سليمان
        </div>
        <div style={{
          marginTop: "10px",
          display: "flex", justifyContent: "center", alignItems: "center", gap: "12px",
        }}>
          <span style={{ color: "#94a3b8", fontSize: "12px" }}>{data.symbol}</span>
          <span style={{ color: "#fbbf24", fontWeight: 900, fontSize: "22px" }}>
            ${data.current_price.toLocaleString()}
          </span>
        </div>
      </div>

      {/* Legend */}
      <Legend />

      {/* Timeframe Grid */}
      <div style={{
        display: "grid",
        gridTemplateColumns: "repeat(auto-fit, minmax(260px, 1fr))",
        gap: "10px",
      }}>
        <TimeframeCard data={data.timeframes.monthly} />
        <TimeframeCard data={data.timeframes.weekly} />
        <TimeframeCard data={data.timeframes.daily} />
        <TimeframeCard data={data.timeframes.hourly} />
      </div>

      {/* Adab Status */}
      <AdabPanel adab={data.adab} />

      {/* Constitution */}
      <div style={{
        marginTop: "16px",
        padding: "12px",
        background: "#0a0a15",
        borderRadius: "10px",
        border: "1px solid #1e1e3a",
        textAlign: "center",
      }}>
        <div style={{ color: "#7c3aed", fontSize: "10px", fontWeight: 700, letterSpacing: "3px", marginBottom: "6px" }}>
          الدستور
        </div>
        <div style={{ color: "#94a3b8", fontSize: "11px", fontFamily: "'Amiri', serif", lineHeight: 1.8 }}>
          السبب أولاً، أو لا دخول ⟡ لا تثق بالصغير إذا خالف الكبير ⟡ التصحيح فرصة، لا تهديد
        </div>
      </div>
    </div>
  );
}
