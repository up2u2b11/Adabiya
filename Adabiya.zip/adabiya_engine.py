"""
╔═══════════════════════════════════════════════════════════════════════════════╗
║                                                                               ║
║     الأدبية - نظام التحليل الكامل                                              ║
║     Al-Adabiya - Complete Analysis System                                     ║
║                                                                               ║
║     دورة 6/6/2006 — 20 مدخل × 4 إطارات = 80 صوت                              ║
║     20 Inputs × 4 Timeframes = 80 Voices                                      ║
║                                                                               ║
║     جميع حقوق الملكية الفكرية محفوظة لعماد سليمان                               ║
║     All IP rights reserved to Emad Suleiman                                   ║
║                                                                               ║
╚═══════════════════════════════════════════════════════════════════════════════╝

البنية:
    BIG   (50%): DOW(25) + SEC(20) + MA(20) + MACDvs0(20) + ROC25vs0(15)
    MED   (30%): ROC25Trend(18) + ROC14vs0(18) + MACDvsMA(22) + RSI_Trend(22) + IMI_Trend(20)
    SMALL (20%): ROC14Trend(12) + ROC7vs0(12) + HIST(16) + STOCH(16) + Reversals(16) + Candles(14) + BB(14)

    + Be Contrarian (حدسي / مشاعر القطيع)
    + Volume System (NET ARROW) موازي

الترميز:
    +1.0  = مؤكد صاعد     (سهم أخضر كامل)
    +0.5  = نصف إشارة صاعد (سهم أخضر + ؟)
     0.0  = محايد / رينج   (مستطيل)
    -0.5  = نصف إشارة هابط (سهم أحمر + ؟)
    -1.0  = مؤكد هابط     (سهم أحمر كامل)
    None  = X مستبعد        (مثل STOCH بين 20-80)
"""

import numpy as np
import pandas as pd
from dataclasses import dataclass, field
from typing import Optional, List, Dict, Tuple
from enum import Enum
import json


# ═══════════════════════════════════════════════════════════════════════════════
# Constants & Configuration
# ═══════════════════════════════════════════════════════════════════════════════

class AdabiyaConfig:
    """
    إعدادات قابلة للتعديل — كل الفترات والأوزان هنا
    All configurable parameters in one place
    """
    # --- Swing Detection ---
    SWING_LOOKBACK = 5          # عدد الشموع لتحديد القمة/القاع
    SWING_MIN_BARS = 3          # الحد الأدنى بين سوينقين

    # --- Moving Averages (Input 5) ---
    MA_FAST_PERIOD = 10
    MA_SLOW_PERIOD = 25
    MA_TYPE = 'SMA'             # SMA or EMA

    # --- MACD ---
    MACD_FAST = 12
    MACD_SLOW = 26
    MACD_SIGNAL = 9

    # --- ROC Periods ---
    ROC_LONG = 25               # for BIG and MED Trend
    ROC_MED = 14                # for MED and SMALL
    ROC_SHORT = 7               # for SMALL

    # --- RSI ---
    RSI_PERIOD = 14

    # --- IMI (Intraday Momentum Index) ---
    IMI_PERIOD = 14

    # --- Stochastic ---
    STOCH_K = 14
    STOCH_D = 3
    STOCH_OVERBOUGHT = 80
    STOCH_OVERSOLD = 20

    # --- Bollinger Bands ---
    BB_PERIOD = 20
    BB_STD = 2.0
    BB_SQUEEZE_PERCENTILE = 10  # أدنى 10% من التاريخ = squeeze

    # --- S.E.C. Channel ---
    SEC_PERIOD = 20

    # --- Oscillator Trend MA (for range fallback) ---
    OSC_MA_FAST = 5
    OSC_MA_SLOW = 10

    # --- Volume ---
    CHAIKIN_FAST = 3
    CHAIKIN_SLOW = 10

    # --- BIG Layer Weights (sum=100) ---
    W_DOW = 25
    W_SEC = 20
    W_MA = 20
    W_MACD_VS_0 = 20
    W_ROC25_VS_0 = 15

    # --- MEDIUM Layer Weights (sum=100) ---
    W_ROC25_TREND = 18
    W_ROC14_VS_0 = 18
    W_MACD_VS_MA = 22
    W_RSI_TREND = 22
    W_IMI_TREND = 20

    # --- SMALL Layer Weights (sum=100) ---
    W_ROC14_TREND = 12
    W_ROC7_VS_0 = 12
    W_HIST = 16
    W_STOCH = 16
    W_REVERSALS = 16
    W_CANDLES = 14
    W_BB = 14
    # Contrarian يُضاف كتعديل خارجي

    # --- Layer Weights ---
    LAYER_BIG = 0.50
    LAYER_MED = 0.30
    LAYER_SMALL = 0.20


# ═══════════════════════════════════════════════════════════════════════════════
# Data Structures
# ═══════════════════════════════════════════════════════════════════════════════

@dataclass
class SwingPoint:
    """نقطة سوينق (قمة أو قاع)"""
    index: int
    price: float
    is_high: bool       # True = قمة، False = قاع
    bar_index: int = 0  # الفهرس في DataFrame الأصلي


@dataclass
class InputSignal:
    """
    نتيجة مدخل واحد من الـ 20
    """
    name: str                           # اسم المدخل
    name_ar: str                        # الاسم بالعربي
    layer: str                          # BIG / MEDIUM / SMALL
    weight: int                         # الوزن داخل الطبقة
    value: Optional[float] = None       # +1, +0.5, 0, -0.5, -1, None=X
    has_divergence: bool = False        # هل يوجد دايفرجنس
    description: str = ""               # وصف الحالة
    description_ar: str = ""            # وصف بالعربي
    raw_value: float = 0.0              # القيمة الخام للمؤشر


@dataclass
class LayerScore:
    """نتيجة طبقة واحدة (BIG/MED/SMALL)"""
    name: str
    inputs: List[InputSignal]
    score: float = 0.0                  # -1 to +1
    active_weight: int = 0              # الوزن الفعلي (بعد استبعاد X)
    total_weight: int = 0               # الوزن الكلي


@dataclass
class VolumeSignal:
    """إشارة الحجم"""
    obv_direction: Optional[float] = None
    macd_vs_0: Optional[float] = None
    macd_vs_ma: Optional[float] = None
    chaikin_vs_0: Optional[float] = None
    chaikin_vs_ma: Optional[float] = None
    hist: Optional[float] = None
    big_score: float = 0.0
    med_score: float = 0.0
    small_score: float = 0.0
    net_arrow: float = 0.0
    description: str = ""


@dataclass
class TimeframeResult:
    """نتيجة إطار زمني واحد"""
    timeframe: str                      # '1M', '1W', '1D', '1H'
    timeframe_ar: str                   # الشهري، الأسبوعي...
    rank: str                           # sultan, wazir, commander, soldier
    rank_ar: str                        # السلطان، الوزير...

    big: LayerScore = None
    medium: LayerScore = None
    small: LayerScore = None

    total_score: float = 0.0            # -1 to +1
    direction: str = "neutral"          # up / down / neutral

    volume: VolumeSignal = None
    net_arrow: float = 0.0              # السهم الصافي بعد دمج الحجم

    support: float = 0.0
    resistance: float = 0.0


@dataclass
class AdabStatus:
    """حالة الأدبية"""
    status: str                         # full_agreement, soldier_correction, etc.
    status_ar: str
    description: str
    description_ar: str
    confidence: float                   # 0-100
    opportunity: str                    # buy / sell / wait
    reasoning: List[str] = field(default_factory=list)


@dataclass
class AdabiyaResult:
    """النتيجة الكاملة للأدبية"""
    symbol: str
    timestamp: str
    current_price: float

    monthly: Optional[TimeframeResult] = None
    weekly: Optional[TimeframeResult] = None
    daily: Optional[TimeframeResult] = None
    hourly: Optional[TimeframeResult] = None

    adab: Optional[AdabStatus] = None

    def to_dict(self) -> dict:
        """تحويل للقاموس للعرض"""
        return {
            'symbol': self.symbol,
            'timestamp': self.timestamp,
            'current_price': self.current_price,
            'timeframes': {
                'monthly': self._tf_dict(self.monthly),
                'weekly': self._tf_dict(self.weekly),
                'daily': self._tf_dict(self.daily),
                'hourly': self._tf_dict(self.hourly),
            },
            'adab': {
                'status': self.adab.status if self.adab else None,
                'status_ar': self.adab.status_ar if self.adab else None,
                'confidence': self.adab.confidence if self.adab else 0,
                'opportunity': self.adab.opportunity if self.adab else 'wait',
                'reasoning': self.adab.reasoning if self.adab else [],
            }
        }

    def _tf_dict(self, tf: Optional[TimeframeResult]) -> Optional[dict]:
        if tf is None:
            return None
        inputs_list = []
        for layer in [tf.big, tf.medium, tf.small]:
            if layer:
                for inp in layer.inputs:
                    inputs_list.append({
                        'name': inp.name,
                        'name_ar': inp.name_ar,
                        'layer': inp.layer,
                        'weight': inp.weight,
                        'value': inp.value,
                        'divergence': inp.has_divergence,
                        'description': inp.description,
                        'raw': inp.raw_value,
                    })
        return {
            'timeframe': tf.timeframe,
            'rank': tf.rank,
            'rank_ar': tf.rank_ar,
            'big_score': tf.big.score if tf.big else 0,
            'med_score': tf.medium.score if tf.medium else 0,
            'small_score': tf.small.score if tf.small else 0,
            'total_score': tf.total_score,
            'direction': tf.direction,
            'net_arrow': tf.net_arrow,
            'support': tf.support,
            'resistance': tf.resistance,
            'inputs': inputs_list,
        }


# ═══════════════════════════════════════════════════════════════════════════════
# Utility Functions — أدوات أساسية
# ═══════════════════════════════════════════════════════════════════════════════

def sma(data: pd.Series, period: int) -> pd.Series:
    """المتوسط المتحرك البسيط"""
    return data.rolling(window=period, min_periods=period).mean()


def ema(data: pd.Series, period: int) -> pd.Series:
    """المتوسط المتحرك الأسي"""
    return data.ewm(span=period, adjust=False).mean()


def moving_average(data: pd.Series, period: int, ma_type: str = 'SMA') -> pd.Series:
    """متوسط متحرك حسب النوع"""
    if ma_type.upper() == 'EMA':
        return ema(data, period)
    return sma(data, period)


def detect_swings(highs: pd.Series, lows: pd.Series,
                  lookback: int = 5, min_bars: int = 3) -> List[SwingPoint]:
    """
    كشف القمم والقيعان — الأداة الأساسية لـ DOW Pattern

    قمة = أعلى نقطة في نافذة lookback من كل جانب
    قاع = أدنى نقطة في نافذة lookback من كل جانب
    """
    swings = []
    n = len(highs)

    # كشف القمم
    for i in range(lookback, n - lookback):
        is_swing_high = True
        for j in range(1, lookback + 1):
            if highs.iloc[i] < highs.iloc[i - j] or highs.iloc[i] < highs.iloc[i + j]:
                is_swing_high = False
                break
        if is_swing_high:
            swings.append(SwingPoint(
                index=len(swings),
                price=highs.iloc[i],
                is_high=True,
                bar_index=i
            ))

    # كشف القيعان
    for i in range(lookback, n - lookback):
        is_swing_low = True
        for j in range(1, lookback + 1):
            if lows.iloc[i] > lows.iloc[i - j] or lows.iloc[i] > lows.iloc[i + j]:
                is_swing_low = False
                break
        if is_swing_low:
            swings.append(SwingPoint(
                index=len(swings),
                price=lows.iloc[i],
                is_high=False,
                bar_index=i
            ))

    # ترتيب حسب الفهرس الزمني
    swings.sort(key=lambda s: s.bar_index)

    # تنظيف: لا نريد قمتين متتاليتين أو قاعين متتاليين
    cleaned = []
    for s in swings:
        if not cleaned:
            cleaned.append(s)
        elif cleaned[-1].is_high != s.is_high:
            cleaned.append(s)
        else:
            # نفس النوع: نختار الأعلى للقمة أو الأدنى للقاع
            if s.is_high and s.price > cleaned[-1].price:
                cleaned[-1] = s
            elif not s.is_high and s.price < cleaned[-1].price:
                cleaned[-1] = s

    return cleaned


def detect_swings_on_series(series: pd.Series, lookback: int = 5) -> List[SwingPoint]:
    """
    كشف القمم والقيعان على سلسلة واحدة (مثل RSI, ROC)
    تُستخدم عند تطبيق DOW Pattern على المذبذبات
    """
    return detect_swings(series, series, lookback=lookback)


def classify_dow_pattern(swings: List[SwingPoint]) -> Tuple[float, str, str]:
    """
    المدخل 3: تصنيف DOW Pattern — 7 حالات

    يعيد: (signal_value, description_en, description_ar)

    الحالات:
    1. Uptrend: HH + HL → +1
    2. Downtrend: LH + LL → -1
    3. Range: Equal highs and lows → 0
    4. Completed FS Down: كان صاعداً، قمة أدنى + كسر قاع → -1
    5. Completed FS Up: كان هابطاً، قاع أعلى + اختراق قمة → +1
    6. NOT Completed FS Down: قمة أدنى لكن لم يُكسر القاع → +0.5?
    7. NOT Completed FS Up: قاع أعلى لكن لم تُخترق القمة → -0.5?
    """
    if len(swings) < 4:
        return 0.0, "Insufficient data", "بيانات غير كافية"

    # آخر 4 نقاط سوينق
    recent = swings[-4:]

    # استخراج آخر قمتين وآخر قاعين
    recent_highs = [s for s in swings if s.is_high]
    recent_lows = [s for s in swings if not s.is_high]

    if len(recent_highs) < 2 or len(recent_lows) < 2:
        return 0.0, "Not enough swings", "سوينقات غير كافية"

    h1, h2 = recent_highs[-2], recent_highs[-1]   # القمة قبل الأخيرة، الأخيرة
    l1, l2 = recent_lows[-2], recent_lows[-1]      # القاع قبل الأخير، الأخير

    hh = h2.price > h1.price    # قمة أعلى
    hl = l2.price > l1.price    # قاع أعلى
    lh = h2.price < h1.price    # قمة أدنى
    ll = l2.price < l1.price    # قاع أدنى
    eh = abs(h2.price - h1.price) / max(h1.price, 1e-10) < 0.002  # قمم متساوية
    el = abs(l2.price - l1.price) / max(l1.price, 1e-10) < 0.002  # قيعان متساوية

    # --- الحالات الواضحة ---

    # Uptrend: HH + HL
    if hh and hl:
        return 1.0, "Uptrend (HH+HL)", "صاعد (قمم أعلى + قيعان أعلى)"

    # Downtrend: LH + LL
    if lh and ll:
        return -1.0, "Downtrend (LH+LL)", "هابط (قمم أدنى + قيعان أدنى)"

    # Range: Equal
    if eh and el:
        return 0.0, "Range", "رينج (محايد)"

    # --- تحول الهيكل (Failure Swing) ---

    # NOT Completed FS Down: قمة أدنى لكن قاع أعلى أو متساو (لم يُكسر القاع)
    if lh and (hl or el):
        return 0.5, "NOT Completed FS Down (LH but low held)", "تحول غير مكتمل هبوطي (قمة أدنى لكن القاع صامد)"

    # NOT Completed FS Up: قاع أعلى لكن قمة أدنى أو متساوية (لم تُخترق القمة)
    if hl and (lh or eh):
        return -0.5, "NOT Completed FS Up (HL but high held)", "تحول غير مكتمل صعودي (قاع أعلى لكن القمة صامدة)"

    # Completed FS Down: كان صاعداً (HH) ثم LH + LL
    if lh and ll:
        return -1.0, "Completed FS Down", "تحول هيكل مكتمل هبوطي"

    # Completed FS Up: كان هابطاً (LL) ثم HL + HH
    if hh and hl:
        return 1.0, "Completed FS Up", "تحول هيكل مكتمل صعودي"

    # --- حالات مختلطة ---
    if hh and ll:
        return 0.0, "Expanding (HH+LL)", "توسع (صعود وهبوط)"
    if lh and hl:
        return 0.0, "Contracting (LH+HL)", "انكماش (مثلث)"

    return 0.0, "Undefined", "غير محدد"


def check_divergence(price_swings: List[SwingPoint],
                     indicator_swings: List[SwingPoint]) -> Tuple[bool, str]:
    """
    فحص الدايفرجنس بين السعر والمذبذب

    Bullish Divergence: السعر LL لكن المذبذب HL → انعكاس صعودي
    Bearish Divergence: السعر HH لكن المذبذب LH → انعكاس هبوطي
    """
    price_highs = [s for s in price_swings if s.is_high]
    price_lows = [s for s in price_swings if not s.is_high]
    ind_highs = [s for s in indicator_swings if s.is_high]
    ind_lows = [s for s in indicator_swings if not s.is_high]

    if len(price_highs) >= 2 and len(ind_highs) >= 2:
        ph1, ph2 = price_highs[-2], price_highs[-1]
        ih1, ih2 = ind_highs[-2], ind_highs[-1]
        # Bearish: السعر قمة أعلى لكن المذبذب قمة أدنى
        if ph2.price > ph1.price and ih2.price < ih1.price:
            return True, "bearish"

    if len(price_lows) >= 2 and len(ind_lows) >= 2:
        pl1, pl2 = price_lows[-2], price_lows[-1]
        il1, il2 = ind_lows[-2], ind_lows[-1]
        # Bullish: السعر قاع أدنى لكن المذبذب قاع أعلى
        if pl2.price < pl1.price and il2.price > il1.price:
            return True, "bullish"

    return False, "none"


# ═══════════════════════════════════════════════════════════════════════════════
# Technical Indicators — حساب المؤشرات
# ═══════════════════════════════════════════════════════════════════════════════

def calc_roc(close: pd.Series, period: int) -> pd.Series:
    """Rate of Change"""
    return ((close - close.shift(period)) / close.shift(period)) * 100


def calc_macd(close: pd.Series, fast: int = 12, slow: int = 26, signal: int = 9):
    """
    MACD — شيخ المؤشرات
    يعيد: (macd_line, signal_line, histogram)
    """
    ema_fast = ema(close, fast)
    ema_slow = ema(close, slow)
    macd_line = ema_fast - ema_slow
    signal_line = ema(macd_line, signal)
    histogram = macd_line - signal_line
    return macd_line, signal_line, histogram


def calc_rsi(close: pd.Series, period: int = 14) -> pd.Series:
    """RSI — مؤشر القوة النسبية"""
    delta = close.diff()
    gain = delta.where(delta > 0, 0.0)
    loss = (-delta).where(delta < 0, 0.0)
    avg_gain = gain.rolling(window=period, min_periods=period).mean()
    avg_loss = loss.rolling(window=period, min_periods=period).mean()
    # Smoothed version
    for i in range(period, len(close)):
        avg_gain.iloc[i] = (avg_gain.iloc[i-1] * (period - 1) + gain.iloc[i]) / period
        avg_loss.iloc[i] = (avg_loss.iloc[i-1] * (period - 1) + loss.iloc[i]) / period
    rs = avg_gain / avg_loss.replace(0, 1e-10)
    return 100 - (100 / (1 + rs))


def calc_imi(open_: pd.Series, close: pd.Series, period: int = 14) -> pd.Series:
    """
    IMI — Intraday Momentum Index
    = 100 * sum(close-open when close>open) / sum(|close-open|)
    """
    up_move = (close - open_).where(close > open_, 0.0)
    total_move = (close - open_).abs()
    imi = (up_move.rolling(period).sum() / total_move.rolling(period).sum().replace(0, 1e-10)) * 100
    return imi


def calc_stochastic(high: pd.Series, low: pd.Series, close: pd.Series,
                    k_period: int = 14, d_period: int = 3):
    """
    Stochastic — يتكلم فقط فوق 80 أو تحت 20
    يعيد: (%K, %D)
    """
    lowest_low = low.rolling(window=k_period).min()
    highest_high = high.rolling(window=k_period).max()
    k = ((close - lowest_low) / (highest_high - lowest_low).replace(0, 1e-10)) * 100
    d = sma(k, d_period)
    return k, d


def calc_bollinger(close: pd.Series, period: int = 20, std_mult: float = 2.0):
    """
    Bollinger Bands
    يعيد: (upper, middle, lower, bandwidth)
    """
    middle = sma(close, period)
    std = close.rolling(window=period).std()
    upper = middle + (std * std_mult)
    lower = middle - (std * std_mult)
    bandwidth = ((upper - lower) / middle) * 100
    return upper, middle, lower, bandwidth


def calc_obv(close: pd.Series, volume: pd.Series) -> pd.Series:
    """On Balance Volume"""
    direction = np.where(close > close.shift(1), 1,
                np.where(close < close.shift(1), -1, 0))
    obv = (volume * direction).cumsum()
    return pd.Series(obv, index=close.index)


def calc_chaikin(high: pd.Series, low: pd.Series, close: pd.Series,
                 volume: pd.Series, fast: int = 3, slow: int = 10) -> pd.Series:
    """Chaikin Oscillator"""
    mfm = ((close - low) - (high - close)) / (high - low).replace(0, 1e-10)
    mfv = mfm * volume
    ad = mfv.cumsum()
    chaikin = ema(ad, fast) - ema(ad, slow)
    return chaikin


def calc_linear_regression_channel(close: pd.Series, period: int = 20):
    """
    S.E.C. Channel — قناة الانحدار الخطي
    يعيد: (upper, center, lower, slope)
    """
    center = pd.Series(np.nan, index=close.index)
    upper = pd.Series(np.nan, index=close.index)
    lower = pd.Series(np.nan, index=close.index)
    slope = pd.Series(np.nan, index=close.index)

    for i in range(period - 1, len(close)):
        y = close.iloc[i - period + 1:i + 1].values
        x = np.arange(period)
        coeffs = np.polyfit(x, y, 1)
        fitted = np.polyval(coeffs, x)
        std = np.std(y - fitted)
        center.iloc[i] = fitted[-1]
        upper.iloc[i] = fitted[-1] + 2 * std
        lower.iloc[i] = fitted[-1] - 2 * std
        slope.iloc[i] = coeffs[0]

    return upper, center, lower, slope


# ═══════════════════════════════════════════════════════════════════════════════
# THE 20 INPUTS — المداخل العشرون
# ═══════════════════════════════════════════════════════════════════════════════

def input_03_dow_pattern(df: pd.DataFrame, cfg: AdabiyaConfig = None) -> InputSignal:
    """
    المدخل 3: DOW Pattern — الأثقل وزناً (25 نقطة)
    يقرأ هيكل السوق: القمم والقيعان
    7 حالات: Uptrend, Downtrend, Range, Completed FS, NOT Completed FS
    """
    if cfg is None:
        cfg = AdabiyaConfig()

    swings = detect_swings(df['high'], df['low'], cfg.SWING_LOOKBACK, cfg.SWING_MIN_BARS)
    value, desc, desc_ar = classify_dow_pattern(swings)

    return InputSignal(
        name="DOW_Pattern", name_ar="نمط داو",
        layer="BIG", weight=cfg.W_DOW,
        value=value,
        description=desc, description_ar=desc_ar
    )


def input_04_sec_channel(df: pd.DataFrame, cfg: AdabiyaConfig = None) -> InputSignal:
    """
    المدخل 4: S.E.C. Channel — Speed/Endurance/Compression (20 نقطة)
    القناة: هل السعر فوق ALL الخطوط أم تحت ALL أم بين؟
    كسر القناة يعكس الحكم.
    """
    if cfg is None:
        cfg = AdabiyaConfig()

    upper, center, lower, slope = calc_linear_regression_channel(df['close'], cfg.SEC_PERIOD)

    last_close = df['close'].iloc[-1]
    last_upper = upper.iloc[-1]
    last_center = center.iloc[-1]
    last_lower = lower.iloc[-1]
    last_slope = slope.iloc[-1]

    if pd.isna(last_upper):
        return InputSignal(name="SEC_Channel", name_ar="القناة",
                          layer="BIG", weight=cfg.W_SEC, value=0.0,
                          description="Insufficient data", description_ar="بيانات غير كافية")

    # القناة صاعدة أم هابطة
    channel_up = last_slope > 0

    # موقع السعر بالنسبة لجميع الخطوط
    above_all = last_close > last_upper
    below_all = last_close < last_lower
    above_center = last_close > last_center
    near_boundary = (abs(last_close - last_upper) / last_upper < 0.003 or
                     abs(last_close - last_lower) / last_lower < 0.003)

    if channel_up:
        if above_all or above_center:
            if near_boundary:
                value, desc = 0.5, "Channel up, price at boundary (+0.5?)"
                desc_ar = "قناة صاعدة، السعر عند الحدود"
            else:
                value, desc = 1.0, "Channel up, price above ALL"
                desc_ar = "قناة صاعدة، السعر فوق الكل"
        elif below_all:
            # كسر القناة الصاعدة للأسفل!
            value, desc = -1.0, "Channel up BROKEN down"
            desc_ar = "القناة الصاعدة مكسورة للأسفل!"
        else:
            value, desc = 0.5, "Channel up, price between lines"
            desc_ar = "قناة صاعدة، السعر بين الخطوط"
    else:  # channel_down
        if below_all or not above_center:
            if near_boundary:
                value, desc = -0.5, "Channel down, price at boundary (-0.5?)"
                desc_ar = "قناة هابطة، السعر عند الحدود"
            else:
                value, desc = -1.0, "Channel down, price below ALL"
                desc_ar = "قناة هابطة، السعر تحت الكل"
        elif above_all:
            # كسر القناة الهابطة للأعلى!
            value, desc = 1.0, "Channel down BROKEN up"
            desc_ar = "القناة الهابطة مكسورة للأعلى!"
        else:
            value, desc = -0.5, "Channel down, price between lines"
            desc_ar = "قناة هابطة، السعر بين الخطوط"

    return InputSignal(
        name="SEC_Channel", name_ar="القناة (SEC)",
        layer="BIG", weight=cfg.W_SEC,
        value=value, description=desc, description_ar=desc_ar,
        raw_value=last_slope
    )


def input_05_moving_averages(df: pd.DataFrame, cfg: AdabiyaConfig = None) -> InputSignal:
    """
    المدخل 5: Moving Averages — الترميز الثلاثي (20 نقطة)

    القواعد:
    1. إغلاق آخر شمعتين فوق المتوسطين + سريع فوق بطيء = +1
    2. إغلاق شمعة واحدة فقط فوق = ±0.5
    3. إغلاق فوق لكن سريع تحت بطيء = -1! (المتوسطات تحكم)
    """
    if cfg is None:
        cfg = AdabiyaConfig()

    ma_fast = moving_average(df['close'], cfg.MA_FAST_PERIOD, cfg.MA_TYPE)
    ma_slow = moving_average(df['close'], cfg.MA_SLOW_PERIOD, cfg.MA_TYPE)

    close_1 = df['close'].iloc[-1]   # آخر إغلاق
    close_2 = df['close'].iloc[-2]   # الإغلاق قبله
    fast_1 = ma_fast.iloc[-1]
    slow_1 = ma_slow.iloc[-1]
    fast_above_slow = fast_1 > slow_1

    close1_above = close_1 > max(fast_1, slow_1)
    close1_below = close_1 < min(fast_1, slow_1)
    close2_above = close_2 > max(ma_fast.iloc[-2], ma_slow.iloc[-2])
    close2_below = close_2 < min(ma_fast.iloc[-2], ma_slow.iloc[-2])

    if close1_above and close2_above and fast_above_slow:
        value = 1.0
        desc = "2 closes above + fast>slow = CONFIRMED UP"
        desc_ar = "إغلاق شمعتين فوق + سريع فوق بطيء = صاعد مؤكد"
    elif close1_below and close2_below and not fast_above_slow:
        value = -1.0
        desc = "2 closes below + fast<slow = CONFIRMED DOWN"
        desc_ar = "إغلاق شمعتين تحت + سريع تحت بطيء = هابط مؤكد"
    elif close1_above and not close2_above:
        value = 0.5
        desc = "1 close above only = HALF signal"
        desc_ar = "إغلاق شمعة واحدة فوق = نصف إشارة"
    elif close1_below and not close2_below:
        value = -0.5
        desc = "1 close below only = HALF signal"
        desc_ar = "إغلاق شمعة واحدة تحت = نصف إشارة"
    elif close1_above and not fast_above_slow:
        # القاعدة الحاسمة: السعر فوق لكن المتوسطات تقول عكس ذلك!
        value = -1.0
        desc = "Price above BUT fast<slow = MA ORDER OVERRIDES → DOWN!"
        desc_ar = "السعر فوق لكن السريع تحت البطيء = المتوسطات تحكم → هابط!"
    elif close1_below and fast_above_slow:
        value = 1.0
        desc = "Price below BUT fast>slow = MA ORDER OVERRIDES → UP!"
        desc_ar = "السعر تحت لكن السريع فوق البطيء = المتوسطات تحكم → صاعد!"
    else:
        value = 0.0
        desc = "Neutral / between MAs"
        desc_ar = "محايد / بين المتوسطات"

    return InputSignal(
        name="Moving_Averages", name_ar="المتوسطات المتحركة",
        layer="BIG", weight=cfg.W_MA,
        value=value, description=desc, description_ar=desc_ar,
        raw_value=fast_1 - slow_1
    )


def input_06_macd_vs_zero(df: pd.DataFrame, cfg: AdabiyaConfig = None) -> InputSignal:
    """
    المدخل 6: MACD vs 0 — الشهادة الأولى لشيخ المؤشرات (20 نقطة)
    ببساطة: فوق الصفر = +1، تحت = -1
    """
    if cfg is None:
        cfg = AdabiyaConfig()

    macd_line, _, _ = calc_macd(df['close'], cfg.MACD_FAST, cfg.MACD_SLOW, cfg.MACD_SIGNAL)
    last_macd = macd_line.iloc[-1]

    if last_macd > 0:
        value, desc = 1.0, f"MACD above zero ({last_macd:.2f})"
        desc_ar = f"MACD فوق الصفر ({last_macd:.2f}) = أرض الثيران"
    elif last_macd < 0:
        value, desc = -1.0, f"MACD below zero ({last_macd:.2f})"
        desc_ar = f"MACD تحت الصفر ({last_macd:.2f}) = أرض الدببة"
    else:
        value, desc = 0.0, "MACD at zero"
        desc_ar = "MACD عند الصفر"

    return InputSignal(
        name="MACD_vs_0", name_ar="MACD مقابل الصفر",
        layer="BIG", weight=cfg.W_MACD_VS_0,
        value=value, description=desc, description_ar=desc_ar,
        raw_value=last_macd
    )


def input_07_roc25_vs_zero(df: pd.DataFrame, cfg: AdabiyaConfig = None) -> InputSignal:
    """
    المدخل 7: ROC(25) vs 0 — الأخف وزناً في BIG (15 نقطة)
    فوق الصفر = +1، تحت = -1
    """
    if cfg is None:
        cfg = AdabiyaConfig()

    roc = calc_roc(df['close'], cfg.ROC_LONG)
    last_roc = roc.iloc[-1]

    if last_roc > 0:
        value = 1.0
        desc = f"ROC(25) above zero ({last_roc:.2f}%)"
        desc_ar = f"ROC(25) فوق الصفر = زخم إيجابي"
    elif last_roc < 0:
        value = -1.0
        desc = f"ROC(25) below zero ({last_roc:.2f}%)"
        desc_ar = f"ROC(25) تحت الصفر = زخم سلبي"
    else:
        value = 0.0
        desc = "ROC(25) at zero"
        desc_ar = "ROC(25) عند الصفر"

    return InputSignal(
        name="ROC25_vs_0", name_ar="ROC(25) مقابل الصفر",
        layer="BIG", weight=cfg.W_ROC25_VS_0,
        value=value, description=desc, description_ar=desc_ar,
        raw_value=last_roc
    )


def _oscillator_trend_signal(osc_series: pd.Series, price_df: pd.DataFrame,
                              name: str, name_ar: str, layer: str, weight: int,
                              cfg: AdabiyaConfig = None) -> InputSignal:
    """
    دالة عامة لقراءة "Trend" على أي مذبذب
    تُطبق DOW Pattern على سلوك المذبذب + Divergence + MA Crossover في الرينج

    تُستخدم لـ: ROC25 Trend, RSI Trend, IMI Trend, ROC14 Trend
    """
    if cfg is None:
        cfg = AdabiyaConfig()

    # كشف سوينقات المذبذب
    osc_swings = detect_swings_on_series(osc_series, lookback=cfg.SWING_LOOKBACK)

    # DOW Pattern على المذبذب
    value, desc, desc_ar = classify_dow_pattern(osc_swings)

    # إذا النتيجة نصف إشارة (؟) → ابحث عن Divergence
    has_div = False
    if abs(value) == 0.5:
        price_swings = detect_swings(price_df['high'], price_df['low'], cfg.SWING_LOOKBACK)
        has_div, div_type = check_divergence(price_swings, osc_swings)
        if has_div:
            # الدايفرجنس يقلب الإشارة!
            if div_type == "bullish":
                value = 1.0
                desc = f"Divergence BULLISH flips signal → UP"
                desc_ar = "دايفرجنس صعودي يقلب الإشارة → صاعد!"
            elif div_type == "bearish":
                value = -1.0
                desc = f"Divergence BEARISH flips signal → DOWN"
                desc_ar = "دايفرجنس هبوطي يقلب الإشارة → هابط!"

    # إذا المذبذب في رينج → MA Crossover
    if value == 0.0:
        osc_fast_ma = moving_average(osc_series, cfg.OSC_MA_FAST)
        osc_slow_ma = moving_average(osc_series, cfg.OSC_MA_SLOW)
        if not pd.isna(osc_fast_ma.iloc[-1]) and not pd.isna(osc_slow_ma.iloc[-1]):
            if osc_fast_ma.iloc[-1] > osc_slow_ma.iloc[-1]:
                value = 1.0
                desc = "Range → MA Crossover UP"
                desc_ar = "رينج → تقاطع المتوسطات صاعد"
            elif osc_fast_ma.iloc[-1] < osc_slow_ma.iloc[-1]:
                value = -1.0
                desc = "Range → MA Crossover DOWN"
                desc_ar = "رينج → تقاطع المتوسطات هابط"

    return InputSignal(
        name=name, name_ar=name_ar,
        layer=layer, weight=weight,
        value=value, has_divergence=has_div,
        description=desc, description_ar=desc_ar,
        raw_value=osc_series.iloc[-1] if len(osc_series) > 0 else 0
    )


def input_08_roc25_trend(df: pd.DataFrame, cfg: AdabiyaConfig = None) -> InputSignal:
    """المدخل 8: ROC(25) Trend — DOW على سلوك ROC"""
    if cfg is None:
        cfg = AdabiyaConfig()
    roc = calc_roc(df['close'], cfg.ROC_LONG)
    return _oscillator_trend_signal(
        roc, df, "ROC25_Trend", "ROC(25) ترند",
        "MEDIUM", cfg.W_ROC25_TREND, cfg
    )


def input_09_roc14_vs_zero(df: pd.DataFrame, cfg: AdabiyaConfig = None) -> InputSignal:
    """المدخل 9: ROC(14) vs 0 — فوق/تحت الصفر"""
    if cfg is None:
        cfg = AdabiyaConfig()
    roc = calc_roc(df['close'], cfg.ROC_MED)
    last_roc = roc.iloc[-1]

    value = 1.0 if last_roc > 0 else (-1.0 if last_roc < 0 else 0.0)
    desc = f"ROC(14) {'above' if value > 0 else 'below' if value < 0 else 'at'} zero ({last_roc:.2f}%)"
    desc_ar = f"ROC(14) {'فوق' if value > 0 else 'تحت' if value < 0 else 'عند'} الصفر"

    return InputSignal(
        name="ROC14_vs_0", name_ar="ROC(14) مقابل الصفر",
        layer="MEDIUM", weight=cfg.W_ROC14_VS_0,
        value=value, description=desc, description_ar=desc_ar,
        raw_value=last_roc
    )


def input_10_macd_vs_signal(df: pd.DataFrame, cfg: AdabiyaConfig = None) -> InputSignal:
    """
    المدخل 10: MACD vs MA (Signal) — الشهادة الثانية لشيخ المؤشرات (22 نقطة)
    MACD فوق خط الإشارة = +1 (الزخم يتسارع)
    MACD تحت خط الإشارة = -1 (الزخم يتباطأ)
    """
    if cfg is None:
        cfg = AdabiyaConfig()

    macd_line, signal_line, _ = calc_macd(df['close'], cfg.MACD_FAST, cfg.MACD_SLOW, cfg.MACD_SIGNAL)
    last_macd = macd_line.iloc[-1]
    last_signal = signal_line.iloc[-1]

    if last_macd > last_signal:
        value = 1.0
        desc = "MACD above Signal → momentum accelerating"
        desc_ar = "MACD فوق خط الإشارة = الزخم يتسارع"
    elif last_macd < last_signal:
        value = -1.0
        desc = "MACD below Signal → momentum decelerating"
        desc_ar = "MACD تحت خط الإشارة = الزخم يتباطأ"
    else:
        value = 0.0
        desc = "MACD = Signal"
        desc_ar = "MACD يساوي خط الإشارة"

    return InputSignal(
        name="MACD_vs_MA", name_ar="MACD مقابل الإشارة",
        layer="MEDIUM", weight=cfg.W_MACD_VS_MA,
        value=value, description=desc, description_ar=desc_ar,
        raw_value=last_macd - last_signal
    )


def input_11_rsi_trend(df: pd.DataFrame, cfg: AdabiyaConfig = None) -> InputSignal:
    """المدخل 11: RSI Trend — DOW على سلوك RSI"""
    if cfg is None:
        cfg = AdabiyaConfig()
    rsi = calc_rsi(df['close'], cfg.RSI_PERIOD)
    return _oscillator_trend_signal(
        rsi, df, "RSI_Trend", "RSI ترند",
        "MEDIUM", cfg.W_RSI_TREND, cfg
    )


def input_12_imi_trend(df: pd.DataFrame, cfg: AdabiyaConfig = None) -> InputSignal:
    """المدخل 12: IMI Trend — DOW على سلوك IMI"""
    if cfg is None:
        cfg = AdabiyaConfig()
    imi = calc_imi(df['open'], df['close'], cfg.IMI_PERIOD)
    return _oscillator_trend_signal(
        imi, df, "IMI_Trend", "IMI ترند",
        "MEDIUM", cfg.W_IMI_TREND, cfg
    )


def input_13_roc14_trend(df: pd.DataFrame, cfg: AdabiyaConfig = None) -> InputSignal:
    """المدخل 13: ROC(14) Trend — DOW على سلوك ROC(14)"""
    if cfg is None:
        cfg = AdabiyaConfig()
    roc = calc_roc(df['close'], cfg.ROC_MED)
    return _oscillator_trend_signal(
        roc, df, "ROC14_Trend", "ROC(14) ترند",
        "SMALL", cfg.W_ROC14_TREND, cfg
    )


def input_14_roc7_vs_zero(df: pd.DataFrame, cfg: AdabiyaConfig = None) -> InputSignal:
    """المدخل 14: ROC(7) vs 0"""
    if cfg is None:
        cfg = AdabiyaConfig()
    roc = calc_roc(df['close'], cfg.ROC_SHORT)
    last_roc = roc.iloc[-1]

    value = 1.0 if last_roc > 0 else (-1.0 if last_roc < 0 else 0.0)

    return InputSignal(
        name="ROC7_vs_0", name_ar="ROC(7) مقابل الصفر",
        layer="SMALL", weight=cfg.W_ROC7_VS_0,
        value=value,
        description=f"ROC(7) = {last_roc:.2f}%",
        description_ar=f"ROC(7) = {last_roc:.2f}%",
        raw_value=last_roc
    )


def input_15_histogram(df: pd.DataFrame, cfg: AdabiyaConfig = None) -> InputSignal:
    """
    المدخل 15: HIST MACD — الشهادة الثالثة لشيخ المؤشرات (16 نقطة)
    أعمدة تنمو = مؤكد (±1)
    أعمدة تتقلص = نصف إشارة (±0.5?)
    """
    if cfg is None:
        cfg = AdabiyaConfig()

    _, _, hist = calc_macd(df['close'], cfg.MACD_FAST, cfg.MACD_SLOW, cfg.MACD_SIGNAL)

    last_hist = hist.iloc[-1]
    prev_hist = hist.iloc[-2]

    above_zero = last_hist > 0
    growing = abs(last_hist) > abs(prev_hist)

    if above_zero:
        if growing:
            value = 1.0
            desc = "Histogram positive & GROWING → confirmed UP"
            desc_ar = "هيستوغرام إيجابي وينمو = صاعد مؤكد"
        else:
            value = 0.5
            desc = "Histogram positive but SHRINKING → weakening (+0.5?)"
            desc_ar = "هيستوغرام إيجابي لكن يتقلص = يضعف (؟)"
    else:
        if growing:  # growing negative = more negative
            value = -1.0
            desc = "Histogram negative & GROWING → confirmed DOWN"
            desc_ar = "هيستوغرام سلبي وينمو = هابط مؤكد"
        else:
            value = -0.5
            desc = "Histogram negative but SHRINKING → weakening (-0.5?)"
            desc_ar = "هيستوغرام سلبي لكن يتقلص = يضعف (؟)"

    return InputSignal(
        name="HIST_MACD", name_ar="هيستوغرام MACD",
        layer="SMALL", weight=cfg.W_HIST,
        value=value, description=desc, description_ar=desc_ar,
        raw_value=last_hist
    )


def input_16_stochastic(df: pd.DataFrame, cfg: AdabiyaConfig = None) -> InputSignal:
    """
    المدخل 16: Stochastic — يتكلم فقط فوق 80 أو تحت 20 (16 نقطة)
    بين 20-80 = X (مستبعد — لا يُحسب!)
    """
    if cfg is None:
        cfg = AdabiyaConfig()

    k, d = calc_stochastic(df['high'], df['low'], df['close'],
                           cfg.STOCH_K, cfg.STOCH_D)

    last_k = k.iloc[-1]
    prev_k = k.iloc[-2]
    last_d = d.iloc[-1]
    prev_d = d.iloc[-2]

    # فوق 80: تقاطع هبوطي = -1
    if last_k >= cfg.STOCH_OVERBOUGHT or prev_k >= cfg.STOCH_OVERBOUGHT:
        if last_k < last_d and prev_k >= prev_d:  # تقاطع K تحت D
            return InputSignal(
                name="Stochastic", name_ar="ستوكاستيك",
                layer="SMALL", weight=cfg.W_STOCH,
                value=-1.0,
                description=f"SELL: K crossed below D above 80 (K={last_k:.1f})",
                description_ar=f"بيع: تقاطع هبوطي فوق 80 (K={last_k:.1f})",
                raw_value=last_k
            )
        elif last_k > cfg.STOCH_OVERBOUGHT:
            return InputSignal(
                name="Stochastic", name_ar="ستوكاستيك",
                layer="SMALL", weight=cfg.W_STOCH,
                value=-0.5,
                description=f"Overbought zone, waiting for cross (K={last_k:.1f})",
                description_ar=f"منطقة تشبع شراء، ننتظر التقاطع (K={last_k:.1f})",
                raw_value=last_k
            )

    # تحت 20: تقاطع صعودي = +1
    if last_k <= cfg.STOCH_OVERSOLD or prev_k <= cfg.STOCH_OVERSOLD:
        if last_k > last_d and prev_k <= prev_d:  # تقاطع K فوق D
            return InputSignal(
                name="Stochastic", name_ar="ستوكاستيك",
                layer="SMALL", weight=cfg.W_STOCH,
                value=1.0,
                description=f"BUY: K crossed above D below 20 (K={last_k:.1f})",
                description_ar=f"شراء: تقاطع صعودي تحت 20 (K={last_k:.1f})",
                raw_value=last_k
            )
        elif last_k < cfg.STOCH_OVERSOLD:
            return InputSignal(
                name="Stochastic", name_ar="ستوكاستيك",
                layer="SMALL", weight=cfg.W_STOCH,
                value=0.5,
                description=f"Oversold zone, waiting for cross (K={last_k:.1f})",
                description_ar=f"منطقة تشبع بيع، ننتظر التقاطع (K={last_k:.1f})",
                raw_value=last_k
            )

    # بين 20 و 80 = X (صامت!)
    return InputSignal(
        name="Stochastic", name_ar="ستوكاستيك",
        layer="SMALL", weight=cfg.W_STOCH,
        value=None,  # X = مستبعد
        description=f"SILENT: Between 20-80 (K={last_k:.1f}) → X",
        description_ar=f"صامت: بين 20 و 80 (K={last_k:.1f}) → لا يُحسب",
        raw_value=last_k
    )


def input_17_reversals(df: pd.DataFrame, cfg: AdabiyaConfig = None) -> InputSignal:
    """
    المدخل 17: Reversals — انعكاسات مؤكدة بـ DOW (16 نقطة)
    الانعكاس + هيكل DOW = إشارة. الانعكاس وحده لا يكفي.
    """
    if cfg is None:
        cfg = AdabiyaConfig()

    # كشف تغير اللون (الاتجاه)
    n = len(df)
    if n < 5:
        return InputSignal(name="Reversals", name_ar="الانعكاسات",
                          layer="SMALL", weight=cfg.W_REVERSALS, value=0.0)

    # آخر 5 شموع
    recent = df.iloc[-5:]
    last_bullish = recent['close'].iloc[-1] > recent['open'].iloc[-1]
    prev_bearish_count = sum(recent['close'].iloc[:-1] < recent['open'].iloc[:-1])
    prev_bullish_count = sum(recent['close'].iloc[:-1] > recent['open'].iloc[:-1])

    # كشف DOW structure
    swings = detect_swings(df['high'], df['low'], cfg.SWING_LOOKBACK)
    _, dow_desc, _ = classify_dow_pattern(swings)

    if last_bullish and prev_bearish_count >= 2:
        # شمعة صعودية بعد سلسلة هبوطية
        if "HL" in dow_desc or "FS Up" in dow_desc:
            value = 1.0
            desc = "Bullish reversal + DOW confirms HL structure"
            desc_ar = "انعكاس صعودي + هيكل قيعان أعلى يؤكد"
        else:
            value = 0.5
            desc = "Bullish reversal but DOW not confirming"
            desc_ar = "انعكاس صعودي لكن الهيكل لا يؤكد بعد"
    elif not last_bullish and prev_bullish_count >= 2:
        # شمعة هبوطية بعد سلسلة صعودية
        if "LH" in dow_desc or "FS Down" in dow_desc:
            value = -1.0
            desc = "Bearish reversal + DOW confirms LH structure"
            desc_ar = "انعكاس هبوطي + هيكل قمم أدنى يؤكد"
        else:
            value = -0.5
            desc = "Bearish reversal but DOW not confirming"
            desc_ar = "انعكاس هبوطي لكن الهيكل لا يؤكد بعد"
    else:
        value = 0.0
        desc = "No reversal pattern detected"
        desc_ar = "لا يوجد نمط انعكاسي"

    return InputSignal(
        name="Reversals", name_ar="الانعكاسات",
        layer="SMALL", weight=cfg.W_REVERSALS,
        value=value, description=desc, description_ar=desc_ar
    )


def input_18_candles(df: pd.DataFrame, cfg: AdabiyaConfig = None) -> InputSignal:
    """
    المدخل 18: Candles — معيار الـ 50% (14 نقطة)
    جسم الشمعة الجديدة >= 50% من جسم السابقة في الاتجاه المعاكس = انعكاس
    الدوجي = X
    """
    if cfg is None:
        cfg = AdabiyaConfig()

    last = df.iloc[-1]
    prev = df.iloc[-2]

    last_body = abs(last['close'] - last['open'])
    prev_body = abs(prev['close'] - prev['open'])
    last_bullish = last['close'] > last['open']
    prev_bullish = prev['close'] > prev['open']

    # الدوجي: جسم صغير جداً
    last_range = last['high'] - last['low']
    if last_range > 0 and last_body / last_range < 0.1:
        return InputSignal(
            name="Candles", name_ar="الشموع",
            layer="SMALL", weight=cfg.W_CANDLES,
            value=None,  # X = الدوجي لا يُحسب
            description="Doji detected → X (excluded)",
            description_ar="دوجي → لا يُحسب",
            raw_value=0
        )

    # هل الجسم الجديد يغطي 50% من السابق في الاتجاه المعاكس؟
    if prev_body > 0 and last_body >= 0.5 * prev_body and last_bullish != prev_bullish:
        if last_bullish:
            value = 1.0
            desc = f"Bullish engulf: body covers {last_body/prev_body*100:.0f}% of prev"
            desc_ar = f"ابتلاع صعودي: الجسم يغطي {last_body/prev_body*100:.0f}% من السابق"
        else:
            value = -1.0
            desc = f"Bearish engulf: body covers {last_body/prev_body*100:.0f}% of prev"
            desc_ar = f"ابتلاع هبوطي: الجسم يغطي {last_body/prev_body*100:.0f}% من السابق"
    else:
        value = 0.0
        desc = "No significant candle pattern"
        desc_ar = "لا يوجد نمط شمعي مهم"

    return InputSignal(
        name="Candles", name_ar="الشموع",
        layer="SMALL", weight=cfg.W_CANDLES,
        value=value, description=desc, description_ar=desc_ar,
        raw_value=last_body
    )


def input_19_bollinger(df: pd.DataFrame, cfg: AdabiyaConfig = None) -> InputSignal:
    """
    المدخل 19: Bollinger Bands — 4 أنماط (14 نقطة)

    1. Squeeze → Breakout direction
    2. Close vs MA (short term)
    3. HOOK: close outside then inside (1 day only = correction not reversal)
    4. Close outside → close inside = Failure Swing indication
    """
    if cfg is None:
        cfg = AdabiyaConfig()

    upper, middle, lower, bandwidth = calc_bollinger(
        df['close'], cfg.BB_PERIOD, cfg.BB_STD
    )

    last_close = df['close'].iloc[-1]
    prev_close = df['close'].iloc[-2]
    last_upper = upper.iloc[-1]
    last_lower = lower.iloc[-1]
    last_middle = middle.iloc[-1]
    prev_upper = upper.iloc[-2]
    prev_lower = lower.iloc[-2]

    # النمط 4: Close Outside → Close Inside (Failure Swing)
    if prev_close > prev_upper and last_close < last_upper:
        return InputSignal(
            name="Bollinger_Bands", name_ar="بولنجر باندز",
            layer="SMALL", weight=cfg.W_BB,
            value=-1.0,
            description="Close outside upper → inside = Failure Swing DOWN",
            description_ar="إغلاق خارج العلوي ثم داخل = FS هبوطي → نحو المتوسط أو الباند الآخر",
            raw_value=bandwidth.iloc[-1]
        )
    if prev_close < prev_lower and last_close > last_lower:
        return InputSignal(
            name="Bollinger_Bands", name_ar="بولنجر باندز",
            layer="SMALL", weight=cfg.W_BB,
            value=1.0,
            description="Close outside lower → inside = Failure Swing UP",
            description_ar="إغلاق خارج السفلي ثم داخل = FS صعودي → نحو المتوسط أو الباند الآخر",
            raw_value=bandwidth.iloc[-1]
        )

    # النمط 3: HOOK (close at band edge then reversal)
    if last_close >= last_upper * 0.998 and prev_close < prev_upper:
        return InputSignal(
            name="Bollinger_Bands", name_ar="بولنجر باندز",
            layer="SMALL", weight=cfg.W_BB,
            value=-0.5,
            description="HOOK at upper band → correction (1 day signal only)",
            description_ar="HOOK عند الباند العلوي → تصحيح (يوم واحد فقط!)",
            raw_value=bandwidth.iloc[-1]
        )
    if last_close <= last_lower * 1.002 and prev_close > prev_lower:
        return InputSignal(
            name="Bollinger_Bands", name_ar="بولنجر باندز",
            layer="SMALL", weight=cfg.W_BB,
            value=0.5,
            description="HOOK at lower band → correction (1 day signal only)",
            description_ar="HOOK عند الباند السفلي → تصحيح (يوم واحد فقط!)",
            raw_value=bandwidth.iloc[-1]
        )

    # النمط 1: Squeeze (low volatility → high volatility coming)
    bw_series = bandwidth.dropna()
    if len(bw_series) > 20:
        percentile = (bw_series < bandwidth.iloc[-1]).sum() / len(bw_series) * 100
        if percentile <= cfg.BB_SQUEEZE_PERCENTILE:
            # Squeeze! Direction based on close vs middle
            if last_close > last_middle:
                return InputSignal(
                    name="Bollinger_Bands", name_ar="بولنجر باندز",
                    layer="SMALL", weight=cfg.W_BB,
                    value=1.0,
                    description="SQUEEZE + price above MA → breakout UP expected",
                    description_ar="ضغط (تقلب منخفض) + السعر فوق المتوسط → انفجار صعودي متوقع",
                    raw_value=bandwidth.iloc[-1]
                )
            else:
                return InputSignal(
                    name="Bollinger_Bands", name_ar="بولنجر باندز",
                    layer="SMALL", weight=cfg.W_BB,
                    value=-1.0,
                    description="SQUEEZE + price below MA → breakout DOWN expected",
                    description_ar="ضغط (تقلب منخفض) + السعر تحت المتوسط → انفجار هبوطي متوقع",
                    raw_value=bandwidth.iloc[-1]
                )

    # النمط 2: Close vs MA (short term signal)
    if last_close > last_middle:
        value = 1.0
        desc = "Close above BB middle → short term UP"
        desc_ar = "إغلاق فوق المتوسط → حركة صغيرة صعودية"
    elif last_close < last_middle:
        value = -1.0
        desc = "Close below BB middle → short term DOWN"
        desc_ar = "إغلاق تحت المتوسط → حركة صغيرة هبوطية"
    else:
        value = 0.0
        desc = "At BB middle"
        desc_ar = "عند المتوسط"

    return InputSignal(
        name="Bollinger_Bands", name_ar="بولنجر باندز",
        layer="SMALL", weight=cfg.W_BB,
        value=value, description=desc, description_ar=desc_ar,
        raw_value=bandwidth.iloc[-1]
    )


# ═══════════════════════════════════════════════════════════════════════════════
# Volume System — نظام الحجم الموازي
# ═══════════════════════════════════════════════════════════════════════════════

def calc_volume_system(df: pd.DataFrame, cfg: AdabiyaConfig = None) -> VolumeSignal:
    """
    نظام الحجم: BIG/MED/SMALL موازي لاستمارة السعر
    BIG: OBV + MACD(volume) vs 0
    MED: MACD(volume) vs MA + CHAIKIN vs 0
    SMALL: CHAIKIN vs MA + HIST MACD(volume)
    """
    if cfg is None:
        cfg = AdabiyaConfig()

    vol_signal = VolumeSignal()

    if 'volume' not in df.columns or df['volume'].sum() == 0:
        vol_signal.description = "No volume data"
        return vol_signal

    # OBV
    obv = calc_obv(df['close'], df['volume'])
    obv_swings = detect_swings_on_series(obv, lookback=cfg.SWING_LOOKBACK)
    obv_val, _, _ = classify_dow_pattern(obv_swings)
    vol_signal.obv_direction = obv_val

    # MACD on Volume
    vol_macd, vol_signal_line, vol_hist = calc_macd(
        df['volume'].astype(float), cfg.MACD_FAST, cfg.MACD_SLOW, cfg.MACD_SIGNAL
    )
    vol_signal.macd_vs_0 = 1.0 if vol_macd.iloc[-1] > 0 else -1.0
    vol_signal.macd_vs_ma = 1.0 if vol_macd.iloc[-1] > vol_signal_line.iloc[-1] else -1.0

    # Chaikin
    chaikin = calc_chaikin(df['high'], df['low'], df['close'], df['volume'],
                          cfg.CHAIKIN_FAST, cfg.CHAIKIN_SLOW)
    chaikin_ma = sma(chaikin, cfg.OSC_MA_SLOW)
    vol_signal.chaikin_vs_0 = 1.0 if chaikin.iloc[-1] > 0 else -1.0
    if not pd.isna(chaikin_ma.iloc[-1]):
        vol_signal.chaikin_vs_ma = 1.0 if chaikin.iloc[-1] > chaikin_ma.iloc[-1] else -1.0

    # HIST
    vol_signal.hist = 1.0 if vol_hist.iloc[-1] > 0 else -1.0

    # Layer scores
    big_inputs = [v for v in [vol_signal.obv_direction, vol_signal.macd_vs_0] if v is not None]
    med_inputs = [v for v in [vol_signal.macd_vs_ma, vol_signal.chaikin_vs_0] if v is not None]
    small_inputs = [v for v in [vol_signal.chaikin_vs_ma, vol_signal.hist] if v is not None]

    vol_signal.big_score = np.mean(big_inputs) if big_inputs else 0
    vol_signal.med_score = np.mean(med_inputs) if med_inputs else 0
    vol_signal.small_score = np.mean(small_inputs) if small_inputs else 0

    vol_signal.net_arrow = (vol_signal.big_score * 0.5 +
                           vol_signal.med_score * 0.3 +
                           vol_signal.small_score * 0.2)

    if vol_signal.net_arrow > 0.3:
        vol_signal.description = "Volume CONFIRMS ↑"
    elif vol_signal.net_arrow < -0.3:
        vol_signal.description = "Volume CONFIRMS ↓"
    else:
        vol_signal.description = "Volume NEUTRAL"

    return vol_signal


# ═══════════════════════════════════════════════════════════════════════════════
# Scoring Engine — محرك التقييم
# ═══════════════════════════════════════════════════════════════════════════════

def calculate_layer_score(inputs: List[InputSignal]) -> LayerScore:
    """
    حساب نتيجة طبقة واحدة (BIG/MED/SMALL)
    X (None) يُستبعد ويُعاد توزيع وزنه
    """
    layer_name = inputs[0].layer if inputs else "?"

    total_weight = sum(inp.weight for inp in inputs)
    active_inputs = [inp for inp in inputs if inp.value is not None]
    active_weight = sum(inp.weight for inp in active_inputs)

    if active_weight == 0:
        return LayerScore(name=layer_name, inputs=inputs,
                         score=0.0, active_weight=0, total_weight=total_weight)

    # الوزن المرجح (مع إعادة توزيع X)
    weighted_sum = sum(inp.value * inp.weight for inp in active_inputs)
    score = weighted_sum / active_weight  # Normalized to [-1, +1]

    return LayerScore(
        name=layer_name, inputs=inputs,
        score=round(score, 4),
        active_weight=active_weight,
        total_weight=total_weight
    )


def calculate_total_score(big: LayerScore, medium: LayerScore,
                          small: LayerScore, cfg: AdabiyaConfig = None) -> float:
    """
    الحساب الكلي: BIG(50%) + MED(30%) + SMALL(20%)
    """
    if cfg is None:
        cfg = AdabiyaConfig()

    total = (big.score * cfg.LAYER_BIG +
             medium.score * cfg.LAYER_MED +
             small.score * cfg.LAYER_SMALL)

    return round(total, 4)


def combine_net_arrow(price_score: float, volume_score: float) -> Tuple[float, str]:
    """
    دمج السعر والحجم → NET ARROW

    جدول الدمج (من صفحة 9):
    السعر مؤكد + الحجم يوافق = مؤكد
    السعر مؤكد + الحجم يعارض = مشكوك (؟)
    السعر نصف + الحجم يؤكد = مؤكد (الحجم يحسم!)
    السعر نصف + الحجم يعارض = ينقلب!
    """
    price_dir = "up" if price_score > 0.2 else ("down" if price_score < -0.2 else "neutral")
    vol_dir = "up" if volume_score > 0.2 else ("down" if volume_score < -0.2 else "neutral")

    # السعر مؤكد
    if abs(price_score) > 0.5:
        if (price_dir == "up" and vol_dir == "up") or (price_dir == "down" and vol_dir == "down"):
            return price_score, "CONFIRMED by volume"
        elif vol_dir == "neutral":
            return price_score * 0.8, "Volume neutral"
        else:
            return price_score * 0.5, "SUSPECT: volume disagrees (?)"

    # السعر نصف إشارة
    elif abs(price_score) > 0.1:
        if vol_dir == "up":
            return abs(price_score) + 0.3, "Volume DECIDES → UP"
        elif vol_dir == "down":
            return -(abs(price_score) + 0.3), "Volume DECIDES → DOWN"
        else:
            return price_score, "Both uncertain"

    # السعر محايد
    else:
        return volume_score * 0.5, "Price neutral, volume leads"


# ═══════════════════════════════════════════════════════════════════════════════
# Adab Hierarchy — الأدبية (التسلسل الهرمي)
# ═══════════════════════════════════════════════════════════════════════════════

def analyze_adab(monthly_score: float, weekly_score: float,
                 daily_score: float, hourly_score: float) -> AdabStatus:
    """
    تحليل الأدبية — العلاقة بين 4 إطارات

    الحالات:
    1. إجماع كامل: الكل في نفس الاتجاه → ثقة عالية
    2. تصحيح الجندي: الساعة تعاكس لكن الثلاثة الكبار متفقون → فرصة ذهبية!
    3. تصحيح القائد: اليومي يعاكس + الساعة معه، لكن الشهري والأسبوعي متفقان
    4. تمرد الوزير: الأسبوعي يعاكس الشهري → خطر! انتظار إلزامي
    5. انتظار: لا وضوح
    """
    # تحديد الاتجاه لكل إطار
    def direction(score):
        if score > 0.15:
            return "up"
        elif score < -0.15:
            return "down"
        return "neutral"

    sultan = direction(monthly_score)
    wazir = direction(weekly_score)
    commander = direction(daily_score)
    soldier = direction(hourly_score)

    reasoning = []

    # 1. إجماع كامل
    if sultan == wazir == commander == soldier and sultan != "neutral":
        dir_ar = "صعود" if sultan == "up" else "هبوط"
        return AdabStatus(
            status="full_agreement",
            status_ar="إجماع كامل",
            description=f"All 4 timeframes agree: {sultan}",
            description_ar=f"الأربعة إطارات متفقة: {dir_ar}",
            confidence=90.0,
            opportunity="buy" if sultan == "up" else "sell",
            reasoning=[
                f"السلطان (الشهري): {sultan} ({monthly_score:+.2f})",
                f"الوزير (الأسبوعي): {wazir} ({weekly_score:+.2f})",
                f"القائد (اليومي): {commander} ({daily_score:+.2f})",
                f"الجندي (الساعة): {soldier} ({hourly_score:+.2f})",
                "إجماع كامل = ثقة عالية"
            ]
        )

    # 2. تصحيح الجندي (الفرصة الذهبية)
    if sultan == wazir == commander and soldier != sultan and sultan != "neutral":
        dir_ar = "صعود" if sultan == "up" else "هبوط"
        opp = "buy" if sultan == "up" else "sell"
        return AdabStatus(
            status="soldier_correction",
            status_ar="تصحيح الجندي",
            description=f"Soldier correcting against {sultan} trend → OPPORTUNITY!",
            description_ar=f"الجندي يصحح ضد ترند {dir_ar} → فرصة ذهبية!",
            confidence=75.0,
            opportunity=opp,
            reasoning=[
                f"السلطان (الشهري): {sultan} ({monthly_score:+.2f})",
                f"الوزير (الأسبوعي): {wazir} ({weekly_score:+.2f})",
                f"القائد (اليومي): {commander} ({daily_score:+.2f})",
                f"⚔️ الجندي (الساعة): {soldier} ({hourly_score:+.2f}) ← يصحح!",
                "تصحيح الجندي في ترند السلطان = فرصة ذهبية"
            ]
        )

    # 3. تصحيح القائد
    if sultan == wazir and commander != sultan and sultan != "neutral":
        dir_ar = "صعود" if sultan == "up" else "هبوط"
        return AdabStatus(
            status="commander_correction",
            status_ar="تصحيح القائد",
            description=f"Commander correcting against {sultan} trend",
            description_ar=f"القائد يصحح ضد ترند {dir_ar}",
            confidence=55.0,
            opportunity="wait",
            reasoning=[
                f"السلطان (الشهري): {sultan} ({monthly_score:+.2f})",
                f"الوزير (الأسبوعي): {wazir} ({weekly_score:+.2f})",
                f"⚔️ القائد (اليومي): {commander} ({daily_score:+.2f}) ← يصحح!",
                f"الجندي (الساعة): {soldier} ({hourly_score:+.2f})",
                "تصحيح القائد = صبر وانتظار لاكتماله"
            ]
        )

    # 4. تمرد الوزير (خطر!)
    if sultan != "neutral" and wazir != sultan and wazir != "neutral":
        return AdabStatus(
            status="wazir_rebellion",
            status_ar="تمرد الوزير",
            description="Wazir rebels against Sultan → MANDATORY WAIT",
            description_ar="الوزير يتمرد على السلطان → انتظار إلزامي!",
            confidence=15.0,
            opportunity="wait",
            reasoning=[
                f"السلطان (الشهري): {sultan} ({monthly_score:+.2f})",
                f"🚨 الوزير (الأسبوعي): {wazir} ({weekly_score:+.2f}) ← تمرد!",
                f"القائد (اليومي): {commander} ({daily_score:+.2f})",
                f"الجندي (الساعة): {soldier} ({hourly_score:+.2f})",
                "تمرد الوزير = لا دخول. انتظار حتى يُحسم الصراع"
            ]
        )

    # 5. انتظار (حالات غير واضحة)
    return AdabStatus(
        status="wait",
        status_ar="انتظار",
        description="Unclear hierarchy → wait for clarity",
        description_ar="التسلسل غير واضح → انتظار",
        confidence=30.0,
        opportunity="wait",
        reasoning=[
            f"السلطان (الشهري): {sultan} ({monthly_score:+.2f})",
            f"الوزير (الأسبوعي): {wazir} ({weekly_score:+.2f})",
            f"القائد (اليومي): {commander} ({daily_score:+.2f})",
            f"الجندي (الساعة): {soldier} ({hourly_score:+.2f})",
            "لا وضوح كافي = الشك يعني انتظار"
        ]
    )


# ═══════════════════════════════════════════════════════════════════════════════
# Main Engine — المحرك الرئيسي
# ═══════════════════════════════════════════════════════════════════════════════

class AdabiyaEngine:
    """
    محرك الأدبية الكامل
    20 مدخل × 4 إطارات = 80 صوت + حجم + أدبية

    الاستخدام:
        engine = AdabiyaEngine()
        result = engine.analyze(monthly_df, weekly_df, daily_df, hourly_df, symbol="BTC")
    """

    def __init__(self, config: AdabiyaConfig = None):
        self.cfg = config or AdabiyaConfig()

    def process_timeframe(self, df: pd.DataFrame,
                          timeframe: str, rank: str) -> TimeframeResult:
        """
        معالجة إطار زمني واحد — الاستمارة الكاملة

        df: بيانات OHLCV
        timeframe: '1M', '1W', '1D', '1H'
        rank: 'sultan', 'wazir', 'commander', 'soldier'
        """
        tf_names = {
            'sultan': ('الشهري', '1M'), 'wazir': ('الأسبوعي', '1W'),
            'commander': ('اليومي', '1D'), 'soldier': ('الساعة', '1H')
        }
        rank_ar = tf_names.get(rank, ('؟', '?'))[0]

        # --- BIG Layer (50%) ---
        big_inputs = [
            input_03_dow_pattern(df, self.cfg),
            input_04_sec_channel(df, self.cfg),
            input_05_moving_averages(df, self.cfg),
            input_06_macd_vs_zero(df, self.cfg),
            input_07_roc25_vs_zero(df, self.cfg),
        ]
        big = calculate_layer_score(big_inputs)

        # --- MEDIUM Layer (30%) ---
        med_inputs = [
            input_08_roc25_trend(df, self.cfg),
            input_09_roc14_vs_zero(df, self.cfg),
            input_10_macd_vs_signal(df, self.cfg),
            input_11_rsi_trend(df, self.cfg),
            input_12_imi_trend(df, self.cfg),
        ]
        medium = calculate_layer_score(med_inputs)

        # --- SMALL Layer (20%) ---
        small_inputs = [
            input_13_roc14_trend(df, self.cfg),
            input_14_roc7_vs_zero(df, self.cfg),
            input_15_histogram(df, self.cfg),
            input_16_stochastic(df, self.cfg),
            input_17_reversals(df, self.cfg),
            input_18_candles(df, self.cfg),
            input_19_bollinger(df, self.cfg),
        ]
        small = calculate_layer_score(small_inputs)

        # --- Total Score ---
        total = calculate_total_score(big, medium, small, self.cfg)

        # --- Volume ---
        volume = calc_volume_system(df, self.cfg)

        # --- NET ARROW ---
        net_arrow, _ = combine_net_arrow(total, volume.net_arrow)

        # --- Direction ---
        if total > 0.2:
            direction = "up"
        elif total < -0.2:
            direction = "down"
        else:
            direction = "neutral"

        # --- Support / Resistance (basic: recent swing low/high) ---
        swings = detect_swings(df['high'], df['low'], self.cfg.SWING_LOOKBACK)
        recent_lows = [s.price for s in swings if not s.is_high]
        recent_highs = [s.price for s in swings if s.is_high]
        support = min(recent_lows[-3:]) if len(recent_lows) >= 3 else (min(recent_lows) if recent_lows else df['low'].min())
        resistance = max(recent_highs[-3:]) if len(recent_highs) >= 3 else (max(recent_highs) if recent_highs else df['high'].max())

        return TimeframeResult(
            timeframe=timeframe, timeframe_ar=rank_ar,
            rank=rank, rank_ar=rank_ar,
            big=big, medium=medium, small=small,
            total_score=total, direction=direction,
            volume=volume, net_arrow=net_arrow,
            support=support, resistance=resistance
        )

    def analyze(self, monthly_df: pd.DataFrame = None,
                weekly_df: pd.DataFrame = None,
                daily_df: pd.DataFrame = None,
                hourly_df: pd.DataFrame = None,
                symbol: str = "BTC") -> AdabiyaResult:
        """
        التحليل الكامل — 4 إطارات + أدبية

        يمكن تمرير أي عدد من الإطارات (1 إلى 4)
        """
        from datetime import datetime

        result = AdabiyaResult(
            symbol=symbol,
            timestamp=datetime.utcnow().isoformat(),
            current_price=0.0
        )

        scores = {}

        if monthly_df is not None and len(monthly_df) >= 30:
            result.monthly = self.process_timeframe(monthly_df, '1M', 'sultan')
            scores['monthly'] = result.monthly.total_score
            result.current_price = monthly_df['close'].iloc[-1]

        if weekly_df is not None and len(weekly_df) >= 30:
            result.weekly = self.process_timeframe(weekly_df, '1W', 'wazir')
            scores['weekly'] = result.weekly.total_score
            result.current_price = weekly_df['close'].iloc[-1]

        if daily_df is not None and len(daily_df) >= 30:
            result.daily = self.process_timeframe(daily_df, '1D', 'commander')
            scores['daily'] = result.daily.total_score
            result.current_price = daily_df['close'].iloc[-1]

        if hourly_df is not None and len(hourly_df) >= 30:
            result.hourly = self.process_timeframe(hourly_df, '1H', 'soldier')
            scores['hourly'] = result.hourly.total_score
            result.current_price = hourly_df['close'].iloc[-1]

        # الأدبية — تحتاج على الأقل إطارين
        if len(scores) >= 2:
            result.adab = analyze_adab(
                scores.get('monthly', 0),
                scores.get('weekly', 0),
                scores.get('daily', 0),
                scores.get('hourly', 0)
            )

        return result


# ═══════════════════════════════════════════════════════════════════════════════
# Pretty Print — طباعة جميلة للنتائج
# ═══════════════════════════════════════════════════════════════════════════════

def signal_emoji(value: Optional[float]) -> str:
    """تحويل القيمة لرمز بصري"""
    if value is None:
        return "  ✖  "  # X = مستبعد
    if value >= 0.9:
        return " 🟢↑ "
    if value >= 0.4:
        return " 🟡↑?"
    if abs(value) < 0.1:
        return " ⬜□ "
    if value <= -0.9:
        return " 🔴↓ "
    if value <= -0.4:
        return " 🟡↓?"
    return " ⬜ "


def print_adabiya_result(result: AdabiyaResult):
    """طباعة النتائج بشكل جميل"""

    print(f"\n{'═' * 80}")
    print(f"  الأدبية — {result.symbol} — {result.timestamp[:19]}")
    print(f"  السعر الحالي: {result.current_price:,.2f}")
    print(f"{'═' * 80}\n")

    timeframes = [
        ('السلطان (الشهري)', result.monthly),
        ('الوزير (الأسبوعي)', result.weekly),
        ('القائد (اليومي)', result.daily),
        ('الجندي (الساعة)', result.hourly),
    ]

    for name, tf in timeframes:
        if tf is None:
            print(f"  {name}: لا توجد بيانات\n")
            continue

        print(f"  ┌─ {name} ─────────────────────────────")
        print(f"  │ Score: {tf.total_score:+.3f}  Direction: {tf.direction}")
        print(f"  │ S/R: {tf.support:,.0f} — {tf.resistance:,.0f}")
        print(f"  │")

        for layer_name, layer in [('BIG  ', tf.big), ('MED  ', tf.medium), ('SMALL', tf.small)]:
            if layer is None:
                continue
            print(f"  │ {layer_name} ({layer.score:+.3f}):")
            for inp in layer.inputs:
                emoji = signal_emoji(inp.value)
                val_str = f"{inp.value:+.1f}" if inp.value is not None else "  X "
                div_str = " 🔀DIV" if inp.has_divergence else ""
                print(f"  │   {emoji} {inp.name_ar:<20} [{val_str}] w={inp.weight} {div_str}")
                print(f"  │         {inp.description_ar}")

        if tf.volume:
            arrow = "↑" if tf.volume.net_arrow > 0.2 else ("↓" if tf.volume.net_arrow < -0.2 else "→")
            print(f"  │")
            print(f"  │ Volume NET ARROW: {arrow} ({tf.volume.net_arrow:+.2f}) — {tf.volume.description}")

        print(f"  └{'─' * 45}\n")

    if result.adab:
        print(f"  ╔{'═' * 50}")
        print(f"  ║ الأدبية: {result.adab.status_ar}")
        print(f"  ║ الثقة: {result.adab.confidence:.0f}%")
        print(f"  ║ الفرصة: {result.adab.opportunity}")
        print(f"  ║")
        for reason in result.adab.reasoning:
            print(f"  ║  • {reason}")
        print(f"  ╚{'═' * 50}\n")


# ═══════════════════════════════════════════════════════════════════════════════
# Export to JSON
# ═══════════════════════════════════════════════════════════════════════════════

def export_result_json(result: AdabiyaResult, filepath: str = None) -> str:
    """تصدير النتائج كـ JSON"""
    data = result.to_dict()
    json_str = json.dumps(data, indent=2, ensure_ascii=False, default=str)
    if filepath:
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(json_str)
    return json_str


if __name__ == "__main__":
    print("الأدبية — محرك التحليل الكامل")
    print("20 مدخل × 4 إطارات = 80 صوت")
    print("جاهز للاستخدام مع بيانات حقيقية")
    print("\nاستخدم: engine = AdabiyaEngine()")
    print("result = engine.analyze(monthly_df, weekly_df, daily_df, hourly_df)")
